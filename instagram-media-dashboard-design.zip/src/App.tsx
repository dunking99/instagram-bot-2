import { AnimatePresence, motion } from "framer-motion";
import {
  Aperture, Archive, ArrowDownToLine, ArrowUpRight, Bell, Check, ChevronDown,
  ChevronRight, CircleHelp, Command, Film, Folder, Grid2X2, Heart,
  Image as ImageIcon, LayoutGrid, ListFilter, Menu, MoreHorizontal, Play,
  Search, Settings, SlidersHorizontal, Sparkles, Star, Upload, UserPlus,
  Users, WandSparkles, X,
} from "lucide-react";
import { useMemo, useState } from "react";

type Result = { id: number; image: string; account: string; date: string; match: number; tags: string[]; type?: "video" | "carousel" };

const results: Result[] = [
  { id: 1, image: "https://images.pexels.com/photos/36976941/pexels-photo-36976941.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=750", account: "urban.muse", date: "Mar 18", match: 97, tags: ["night", "streetwear"], type: "carousel" },
  { id: 2, image: "https://images.pexels.com/photos/9821885/pexels-photo-9821885.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=750", account: "offduty.archive", date: "Feb 26", match: 94, tags: ["architecture", "full body"] },
  { id: 3, image: "https://images.pexels.com/photos/29708198/pexels-photo-29708198.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=750", account: "streetframe", date: "Jan 12", match: 91, tags: ["group", "streetwear"], type: "video" },
  { id: 4, image: "https://images.pexels.com/photos/35209606/pexels-photo-35209606.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=750", account: "new.wave.cast", date: "Dec 8", match: 89, tags: ["portrait", "editorial"] },
  { id: 5, image: "https://images.pexels.com/photos/14470367/pexels-photo-14470367.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=750", account: "urban.muse", date: "Nov 21", match: 86, tags: ["duo", "monochrome"] },
  { id: 6, image: "https://images.pexels.com/photos/3095424/pexels-photo-3095424.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=750", account: "offduty.archive", date: "Oct 4", match: 83, tags: ["street", "full body"] },
  { id: 7, image: "https://images.pexels.com/photos/20451157/pexels-photo-20451157.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=750", account: "streetframe", date: "Sep 19", match: 81, tags: ["night", "portrait"] },
  { id: 8, image: "https://images.pexels.com/photos/6220662/pexels-photo-6220662.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=750", account: "new.wave.cast", date: "Aug 14", match: 79, tags: ["group", "editorial"] },
];

const nav = [
  { label: "Discover", icon: Sparkles }, { label: "Library", icon: LayoutGrid },
  { label: "Favourites", icon: Heart, count: 24 }, { label: "Collections", icon: Folder },
];
const accounts = ["urban.muse", "offduty.archive", "streetframe", "new.wave.cast"];

function Logo() {
  return <div className="brand"><div className="brand-mark"><Aperture size={20} strokeWidth={2.2} /></div><span>Luma</span></div>;
}

function Sidebar({ open, close, active, setActive }: { open: boolean; close: () => void; active: string; setActive: (v: string) => void }) {
  return <>
    <AnimatePresence>{open && <motion.button aria-label="Close navigation" className="mobile-scrim" onClick={close} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} />}</AnimatePresence>
    <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
      <div className="sidebar-top"><Logo /><button aria-label="Close menu" className="icon-button mobile-close" onClick={close}><X size={18} /></button></div>
      <nav className="main-nav">
        <span className="nav-label">Workspace</span>
        {nav.map((item) => <button key={item.label} className={active === item.label ? "nav-item active" : "nav-item"} onClick={() => { setActive(item.label); close(); }}><item.icon size={18} strokeWidth={1.8} /><span>{item.label}</span>{item.count && <span className="nav-count">{item.count}</span>}</button>)}
        <span className="nav-label nav-label-spaced">Manage</span>
        <button className="nav-item"><UserPlus size={18} /><span>Accounts</span></button>
        <button className="nav-item"><Upload size={18} /><span>Import media</span></button>
        <button className="nav-item"><Archive size={18} /><span>Indexing</span><span className="status-dot" /></button>
      </nav>
      <div className="storage"><div className="storage-copy"><span>Local storage</span><span>18.5 GB</span></div><div className="storage-track"><div /></div><p>18.5 of 48 GB used</p></div>
      <div className="profile"><div className="avatar">JD</div><div><strong>Local workspace</strong><span>Session active</span></div><MoreHorizontal size={18} /></div>
    </aside>
  </>;
}

function FilterPanel({ close }: { close: () => void }) {
  const [confidence, setConfidence] = useState(72);
  return <motion.aside className="filter-panel" initial={{ x: 440 }} animate={{ x: 0 }} exit={{ x: 440 }} transition={{ type: "spring", damping: 28, stiffness: 260 }}>
    <div className="panel-heading"><div><p>Refine search</p><span>Fine-tune ranking and sources</span></div><button aria-label="Close filters" className="icon-button" onClick={close}><X size={19} /></button></div>
    <div className="panel-section"><label>Accounts</label>{accounts.map((account, index) => <button className="check-row" key={account}><span className={`checkbox ${index < 3 ? "checked" : ""}`}>{index < 3 && <Check size={12} />}</span><span>@{account}</span><span>{[1264, 842, 619, 380][index]}</span></button>)}</div>
    <div className="panel-section"><label>Match direction</label><div className="segment"><button className="selected">Best matches</button><button>Lowest scores</button></div></div>
    <div className="panel-section"><div className="range-label"><label>Tag confidence</label><strong>{confidence}%</strong></div><input aria-label="Tag confidence" className="range" type="range" min="30" max="95" value={confidence} onChange={(e) => setConfidence(Number(e.target.value))} style={{ "--range": `${(confidence - 30) / .65}%` } as React.CSSProperties} /><div className="range-ends"><span>Broad</span><span>Precise</span></div></div>
    <div className="panel-section"><label>Media</label><button className="toggle-row"><span><Film size={17} />Include videos</span><span className="toggle on"><i /></span></button><button className="toggle-row"><span><Grid2X2 size={17} />Expand carousels</span><span className="toggle on"><i /></span></button><button className="toggle-row"><span><WandSparkles size={17} />Mirror pose matching</span><span className="toggle"><i /></span></button></div>
    <div className="panel-actions"><button className="text-button">Reset all</button><button className="primary small" onClick={close}>Show 164 results</button></div>
  </motion.aside>;
}

function ResultTile({ item, selected, toggle, favourite, toggleFavourite, index }: { item: Result; selected: boolean; toggle: () => void; favourite: boolean; toggleFavourite: () => void; index: number }) {
  return <motion.article className={`result-tile ${selected ? "is-selected" : ""}`} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * .045 }}>
    <img src={item.image} alt={`${item.account} search result`} />
    <button aria-label={selected ? "Deselect image" : "Select image"} className="select-check" onClick={toggle}>{selected && <Check size={13} strokeWidth={3} />}</button>
    {item.type && <span className="media-type">{item.type === "video" ? <Play size={13} fill="currentColor" /> : <Grid2X2 size={13} />}</span>}
    <div className="image-shade" /><div className="match">{item.match}% match</div>
    <button aria-label="Toggle favourite" className={`heart ${favourite ? "favourite" : ""}`} onClick={toggleFavourite}><Heart size={18} fill={favourite ? "currentColor" : "none"} /></button>
    <div className="tile-caption"><strong>@{item.account}</strong><span>{item.date}</span></div>
  </motion.article>;
}

function EmptyView({ active }: { active: string }) {
  const content: Record<string, [string, string, typeof Heart]> = {
    Library: ["Your entire visual archive", "Browse every indexed Instagram post and imported local file.", LayoutGrid],
    Favourites: ["The ones worth keeping", "Your 24 saved images, gathered in one quiet place.", Heart],
    Collections: ["Curate your own stories", "Group images into focused collections for projects and references.", Folder],
  };
  const [title, copy, Icon] = content[active] || content.Library;
  return <main className="empty-view"><motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}><Icon size={32} strokeWidth={1.4} /><h1>{title}</h1><p>{copy}</p><button className="primary">Explore media</button></motion.div></main>;
}

export default function App() {
  const [active, setActive] = useState("Discover");
  const [sidebar, setSidebar] = useState(false);
  const [filters, setFilters] = useState(false);
  const [query, setQuery] = useState("editorial street style at night");
  const [searchedQuery, setSearchedQuery] = useState(query);
  const [searching, setSearching] = useState(false);
  const [selected, setSelected] = useState<number[]>(results.map((r) => r.id));
  const [favourites, setFavourites] = useState<number[]>([2, 5]);
  const [view, setView] = useState<"grid" | "large">("grid");
  const [sourceMode, setSourceMode] = useState("Text");
  const allSelected = selected.length === results.length;
  const statusText = useMemo(() => searching ? "Searching 3 accounts..." : `164 matches for “${searchedQuery}”`, [searching, searchedQuery]);
  function runSearch() { if (!query.trim() || searching) return; setSearching(true); window.setTimeout(() => { setSearchedQuery(query.trim()); setSearching(false); }, 1200); }

  if (active !== "Discover") return <div className="app-shell"><Sidebar open={sidebar} close={() => setSidebar(false)} active={active} setActive={setActive} /><section className="main-wrap"><header className="topbar"><button aria-label="Open menu" className="icon-button menu-button" onClick={() => setSidebar(true)}><Menu size={20} /></button><span className="page-title">{active}</span><div className="top-actions"><button aria-label="Search" className="icon-button"><Search size={18} /></button><button aria-label="Settings" className="icon-button"><Settings size={18} /></button></div></header><EmptyView active={active} /></section></div>;

  return <div className="app-shell">
    <Sidebar open={sidebar} close={() => setSidebar(false)} active={active} setActive={setActive} />
    <section className="main-wrap">
      <header className="topbar"><button aria-label="Open menu" className="icon-button menu-button" onClick={() => setSidebar(true)}><Menu size={20} /></button><div className="crumb"><span>Discover</span><ChevronRight size={14} /><strong>New search</strong></div><div className="top-actions"><button className="command-search"><Search size={16} /><span>Quick find</span><kbd><Command size={11} /> K</kbd></button><button aria-label="Notifications" className="icon-button notification"><Bell size={18} /><i /></button><button aria-label="Help" className="icon-button"><CircleHelp size={18} /></button></div></header>
      <main className="content">
        <motion.section className="search-stage" initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}>
          <div className="search-heading"><div><span className="eyebrow"><Sparkles size={13} /> AI visual search</span><h1>Find the frame<br />you have in mind.</h1></div><p>Search your indexed Instagram archive by scene, visual reference, pose, or tags.</p></div>
          <div className="search-box">
            <div className="mode-tabs">{["Text", "Image", "Pose", "Tags"].map((mode) => <button key={mode} className={sourceMode === mode ? "active" : ""} onClick={() => setSourceMode(mode)}>{mode === "Text" && <Search size={14} />}{mode === "Image" && <ImageIcon size={14} />}{mode === "Pose" && <Users size={14} />}{mode === "Tags" && <ListFilter size={14} />}{mode}</button>)}</div>
            <div className="query-row"><input value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => e.key === "Enter" && runSearch()} placeholder={sourceMode === "Text" ? "Describe a scene, outfit, mood, or moment..." : `Choose a ${sourceMode.toLowerCase()} reference...`} />{query && <button aria-label="Clear query" className="clear-query" onClick={() => setQuery("")}><X size={17} /></button>}<button className="primary search-button" onClick={runSearch}>{searching ? <span className="spinner" /> : <Sparkles size={17} />}<span>{searching ? "Searching" : "Search"}</span></button></div>
            <div className="search-options"><button><span className="account-stack"><i>U</i><i>O</i><i>S</i></span>3 accounts<ChevronDown size={14} /></button><span className="divider" /><button onClick={() => setFilters(true)}><SlidersHorizontal size={15} />Filters <span className="filter-count">4</span></button><button><Archive size={15} />Saved thumbnails<ChevronDown size={14} /></button><span className="search-model"><span /> SigLIP index</span></div>
          </div>
        </motion.section>
        <section className="results-section">
          <div className="results-head"><div><h2>{statusText}</h2><span>{searching ? "Reading local indexes" : "Ranked across 2,725 indexed images"}</span></div><div className="result-tools"><button className="select-all" onClick={() => setSelected(allSelected ? [] : results.map((r) => r.id))}><span className={`checkbox ${allSelected ? "checked" : ""}`}>{allSelected && <Check size={12} />}</span>{allSelected ? "All selected" : "Select all"}</button><div className="view-toggle"><button aria-label="Compact grid" className={view === "grid" ? "active" : ""} onClick={() => setView("grid")}><Grid2X2 size={16} /></button><button aria-label="Large grid" className={view === "large" ? "active" : ""} onClick={() => setView("large")}><LayoutGrid size={16} /></button></div></div></div>
          <div className={`results-grid ${view === "large" ? "large" : ""} ${searching ? "is-loading" : ""}`}>{results.map((item, index) => <ResultTile key={item.id} item={item} index={index} selected={selected.includes(item.id)} toggle={() => setSelected((current) => current.includes(item.id) ? current.filter((id) => id !== item.id) : [...current, item.id])} favourite={favourites.includes(item.id)} toggleFavourite={() => setFavourites((current) => current.includes(item.id) ? current.filter((id) => id !== item.id) : [...current, item.id])} />)}</div>
        </section>
      </main>
      <AnimatePresence>{selected.length > 0 && <motion.div className="selection-bar" initial={{ opacity: 0, y: 28, x: "-50%" }} animate={{ opacity: 1, y: 0, x: "-50%" }} exit={{ opacity: 0, y: 20, x: "-50%" }}><span><strong>{selected.length}</strong> selected</span><i /><button><Play size={16} />Slideshow</button><button><Star size={16} />Favourite</button><button><ArrowDownToLine size={16} />Save</button><button className="fetch-action"><ArrowUpRight size={16} />Fetch full size</button><button aria-label="Clear selection" className="close-selection" onClick={() => setSelected([])}><X size={17} /></button></motion.div>}</AnimatePresence>
    </section>
    <AnimatePresence>{filters && <><motion.button aria-label="Close filters" className="panel-scrim" onClick={() => setFilters(false)} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} /><FilterPanel close={() => setFilters(false)} /></>}</AnimatePresence>
  </div>;
}