import type { Account, Frame, TagGroup } from "./data";

export type TagPick = { group: TagGroup; tag: string };

export type Scored = Frame & {
  score: number;
  slideIndex: number;
  resultId: string;
};

export type Mix = "pool" | "spread";
export type Polarity = "best" | "worst";
export type ResultMode = "thumbs" | "full" | "links";
export type CacheMode = "cache" | "refresh" | "rebuild";
export type CarouselMode = "cover" | "all" | "index";

export type SearchParams = {
  frames: Frame[];
  accounts: Account[];
  selected: string[];
  model: "siglip" | "clip";
  text: string;
  useText: boolean;
  useImage: boolean;
  refImage: string | null;
  imageWeight: number;
  usePose: boolean;
  poseImage: string | null;
  mirrorPose: boolean;
  tags: TagPick[];
  confidence: number;
  polarity: Polarity;
  count: number;
  takeAll: boolean;
  cap: number;
  mix: Mix;
  dateFrom: string;
  dateTo: string;
  includeVideo: boolean;
  carouselMode: CarouselMode;
  cacheMode: CacheMode;
  clipLength: number;
  resultMode: ResultMode;
  seed: number;
  forceRandom?: boolean;
};

export type SearchOutput = {
  results: Scored[];
  skippedModel: string[];
  skippedPose: string[];
  excludedLocal: number;
  excludedVideo: number;
  pool: number;
  mode: "random" | "ranked";
};

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967295;
}

function tokenize(s: string) {
  return s.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 2);
}

function spread(items: Scored[], accounts: string[]) {
  const buckets = new Map<string, Scored[]>();
  for (const a of accounts) buckets.set(a, []);
  for (const item of items) buckets.get(item.account)?.push(item);
  const out: Scored[] = [];
  const max = Math.max(0, ...[...buckets.values()].map((b) => b.length));
  for (let i = 0; i < max; i++) {
    for (const a of accounts) {
      const item = buckets.get(a)?.[i];
      if (item) out.push(item);
    }
  }
  return out;
}

export function computeSearch(p: SearchParams): SearchOutput {
  const ready = p.selected.filter((h) => p.accounts.find((a) => a.handle === h)?.models[p.model]);
  const skippedModel = p.selected.filter((h) => !ready.includes(h));
  const poseOn = !p.forceRandom && p.usePose && !!p.poseImage;
  const skippedPose = poseOn ? ready.filter((h) => !p.accounts.find((a) => a.handle === h)?.pose) : [];
  const usable = poseOn ? ready.filter((h) => !skippedPose.includes(h)) : ready;

  let pool = p.frames.filter((f) => usable.includes(f.account));
  const poolCount = pool.length;

  let excludedLocal = 0;
  if (p.dateFrom || p.dateTo) {
    excludedLocal = pool.filter((f) => f.local || !f.date).length;
    pool = pool.filter((f) => {
      if (f.local || !f.date) return false;
      if (p.dateFrom && f.date < p.dateFrom) return false;
      if (p.dateTo && f.date > p.dateTo) return false;
      return true;
    });
  }

  let excludedVideo = 0;
  if (!p.includeVideo) {
    excludedVideo = pool.filter((f) => !!f.video || f.kind === "reel").length;
    pool = pool.filter((f) => !(f.video || f.kind === "reel"));
  }

  if (!p.forceRandom && p.tags.length) {
    pool = pool.filter((f) =>
      p.tags.every((t) => {
        if (f.tags[t.group] !== t.tag) return false;
        if (t.group === "setting" || t.group === "outfit" || t.group === "shot") {
          return f.conf[t.group] >= p.confidence;
        }
        return true;
      }),
    );
  }

  const textOn = !p.forceRandom && p.useText && p.text.trim().length > 0;
  const imageOn = !p.forceRandom && p.useImage && !!p.refImage;
  const mode: SearchOutput["mode"] =
    !textOn && !imageOn && !poseOn && !(p.tags.length && !p.forceRandom) ? "random" : "ranked";

  const refFrame = imageOn ? p.frames.find((f) => f.src === p.refImage) : undefined;
  const poseFrame = poseOn ? p.frames.find((f) => f.src === p.poseImage) : undefined;
  const words = textOn ? tokenize(p.text) : [];

  let scored: Scored[] = pool.map((f) => {
    const base = p.model === "siglip" ? f.sig : f.clip;
    let score = base;
    if (mode === "random") {
      score = hash(`${f.id}:${p.seed}`);
    } else {
      let textScore: number | null = null;
      if (textOn && words.length) {
        const bag = tokenize(`${f.caption} ${Object.values(f.tags).join(" ")}`);
        const hits = words.filter((w) => bag.some((b) => b.includes(w) || w.includes(b))).length;
        const lexical = hits / words.length;
        const semantic = 0.08 + hash(`${f.id}:${p.text}`) * 0.18;
        textScore = hits ? Math.min(0.99, lexical * 0.82 + 0.18) : semantic;
        score = 0.28 * base + 0.72 * textScore;
      }
      if (imageOn && p.refImage) {
        let img = 0.22 + hash(`${f.id}:${p.refImage.slice(0, 80)}:${p.refImage.length}`) * 0.5;
        if (refFrame) {
          if (f.tags.setting === refFrame.tags.setting && f.tags.setting !== "none") img += 0.12;
          if (f.tags.outfit === refFrame.tags.outfit && f.tags.outfit !== "none") img += 0.1;
          if (f.tags.shot === refFrame.tags.shot) img += 0.05;
          if (f.src === refFrame.src) img = 0.98;
        }
        const w = textScore != null ? p.imageWeight : 1;
        const textPart = textScore != null ? score : base;
        score = textPart * (1 - w) + Math.min(0.99, img) * w;
      }
      if (poseOn && p.poseImage) {
        let pose = 0.16 + hash(`${f.id}:${p.mirrorPose ? "m" : "p"}:${p.poseImage.length}`) * 0.34;
        if (poseFrame && poseFrame.tags.pose !== "none") {
          if (f.tags.pose === poseFrame.tags.pose) pose = 0.72 + hash(f.id) * 0.18;
          if (f.tags.arms === poseFrame.tags.arms && f.tags.arms !== "none") pose += 0.06;
          if (p.mirrorPose && f.tags.pose === poseFrame.tags.pose) pose += 0.04;
          if (f.src === poseFrame.src) pose = 0.97;
        }
        const scene = textOn ? score : base * 0.45;
        score = Math.min(0.99, pose) * 0.64 + scene * 0.36;
      }
      if (!textOn && !imageOn && !poseOn && p.tags.length) {
        const conf = (f.conf.setting + f.conf.outfit + f.conf.shot) / 3;
        score = 0.4 * base + 0.6 * conf;
      }
    }
    return {
      ...f,
      score: Math.max(0.02, Math.min(0.99, score)),
      slideIndex: 0,
      resultId: f.id,
    };
  });

  scored.sort((a, b) => (mode === "ranked" && p.polarity === "worst" ? a.score - b.score : b.score - a.score));

  if (p.mix === "spread") scored = spread(scored, usable);

  if (p.carouselMode === "all") {
    scored = scored.flatMap((item) => {
      if (item.kind !== "carousel" || item.slides.length < 2) return [item];
      return item.slides.map((src, i) => ({
        ...item,
        src,
        slideIndex: i,
        resultId: `${item.id}:${i}`,
        score: Math.max(0.02, item.score - i * 0.015),
        wide: i === 0 ? item.wide : false,
      }));
    });
    scored.sort((a, b) => (mode === "ranked" && p.polarity === "worst" ? a.score - b.score : b.score - a.score));
  }

  const limit = Math.max(1, p.takeAll ? p.cap : p.count);
  return {
    results: scored.slice(0, limit),
    skippedModel,
    skippedPose,
    excludedLocal,
    excludedVideo,
    pool: poolCount,
    mode,
  };
}

export function buildLog(p: SearchParams, out: SearchOutput): string[] {
  const lines = [
    `random_post.py   ${p.selected.map((h) => "@" + h).join("  ")}`,
    p.cacheMode === "rebuild"
      ? "cache   rebuild from scratch · a profile read can take several minutes"
      : p.cacheMode === "refresh"
        ? "cache   checking for new posts against the saved session"
        : `cache   saved ${p.model} index`,
  ];
  if (out.skippedModel.length) {
    lines.push(`skip   no ${p.model} index · ${out.skippedModel.map((h) => "@" + h).join(", ")}`);
  }
  if (out.skippedPose.length) {
    lines.push(`skip   no pose index · ${out.skippedPose.map((h) => "@" + h).join(", ")}`);
  }
  lines.push(`pool   ${out.pool} frames in the selected indexes`);
  if (out.mode === "random") {
    lines.push("rank   random draw — no text, image, pose, or tags");
  } else {
    if (p.useText && p.text.trim()) lines.push(`rank   text  “${p.text.trim().slice(0, 88)}”`);
    if (p.useImage && p.refImage) {
      const w = Math.round(p.imageWeight * 100);
      lines.push(`rank   reference image · ${w}% image / ${100 - w}% text`);
    }
    if (p.usePose && p.poseImage) lines.push(`rank   pose · mirror ${p.mirrorPose ? "on" : "off"}`);
    if (p.tags.length) {
      lines.push(`require   ${p.tags.map((t) => t.tag).join(" + ")} · confidence ≥ ${p.confidence.toFixed(2)}`);
    }
  }
  if (p.dateFrom || p.dateTo) {
    lines.push(`date   ${p.dateFrom || "…"} → ${p.dateTo || "…"} · ${out.excludedLocal} local files excluded`);
  }
  lines.push(
    p.includeVideo
      ? `video   included · imported clips cut to ${p.clipLength.toFixed(1)}s`
      : `video   reels off${out.excludedVideo ? ` · ${out.excludedVideo} held back` : ""}`,
  );
  lines.push(
    p.carouselMode === "all"
      ? "carousel   every slide"
      : p.carouselMode === "index"
        ? "carousel   promising threads marked for slide indexing"
        : "carousel   cover frame only",
  );
  lines.push(
    `mix   ${p.mix} · ${out.mode === "random" ? "draw" : p.polarity} · ${p.takeAll ? `all ≤ ${p.cap}` : p.count}`,
  );
  lines.push(
    `output   ${p.resultMode === "thumbs" ? "saved thumbnails" : p.resultMode === "full" ? "full-size into picks/" : "links only"}`,
  );
  lines.push(`${out.results.length} frame${out.results.length === 1 ? "" : "s"}`);
  return lines;
}
