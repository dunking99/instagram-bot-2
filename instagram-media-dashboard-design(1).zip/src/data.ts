export type TagGroup = "setting" | "outfit" | "shot" | "pose" | "arms";

export type Frame = {
  id: string;
  account: string;
  src: string;
  video?: string;
  wide?: boolean;
  date: string | null;
  code: string | null;
  kind: "photo" | "reel" | "carousel";
  slides: string[];
  tags: Record<TagGroup, string>;
  conf: { setting: number; outfit: number; shot: number };
  caption: string;
  local: boolean;
  sig: number;
  clip: number;
  focus: string;
  path?: string;
};

export type Account = {
  handle: string;
  kind: "instagram" | "local";
  photos: number;
  reels: number;
  carousels: number;
  slidesIndexed: number;
  slidesTotal: number;
  pose: boolean;
  carouselDetected: boolean;
  models: { siglip: boolean; clip: boolean };
  prepared: string | null;
  libraryBuilt: boolean;
  cover: string;
};

export type Source = {
  id: string;
  name: string;
  path: string;
  kind: "images" | "videos";
  indexed: number;
  pending: number;
  added: string;
  feeds?: string;
};

export type PilotShot = {
  id: string;
  screenshot: string;
  crop: string;
  score: number;
  file: string;
  person: boolean;
};

export type Fav = {
  id: string;
  account: string;
  src: string;
  code: string | null;
  savedAt: string;
  filename: string;
  caption: string;
};

export type JobKind = "prepare" | "index" | "import" | "pose" | "detect" | "library";

export type Job = {
  id: string;
  title: string;
  kind: JobKind;
  account?: string;
  status: "running" | "stopped" | "done";
  progress: number;
  log: string[];
  started: number;
  step: number;
  workers?: number;
  model?: "siglip" | "clip";
  carouselCount?: number;
  untilDone?: boolean;
  batch?: number;
  sourceId?: string;
  logPath: string;
  pid: number;
  applied?: boolean;
  sourceKind?: "images" | "videos";
  sourceName?: string;
  pendingCount?: number;
  path?: string;
  createCollection?: boolean;
};

export const TAGS: Record<TagGroup, string[]> = {
  setting: ["street", "beach", "studio", "cafe", "indoor", "nature"],
  outfit: ["blazer", "dress", "casual", "coat", "monochrome", "knit"],
  shot: ["full", "three-quarter", "close-up", "wide", "detail"],
  pose: ["standing", "walking", "seated", "leaning"],
  arms: ["at sides", "crossed", "raised", "in pockets", "one raised"],
};

export const GROUP_LABEL: Record<TagGroup, string> = {
  setting: "Setting",
  outfit: "Outfit",
  shot: "Shot",
  pose: "Pose",
  arms: "Arms",
};

export const MODEL_TAGS: TagGroup[] = ["setting", "outfit", "shot"];

export function daysAgo(n: number) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

export function formatDate(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${d} ${months[(m || 1) - 1]} ${y}`;
}

export function titleCase(s: string) {
  return s.replace(/\b\w/g, (c) => c.toUpperCase());
}

export function slugify(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "collection";
}

const photo = (id: number, wide = false) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=${wide ? 1100 : 1500}&w=${wide ? 1600 : 1100}`;

export const MEDIA = {
  blazer: photo(4816586),
  stone: photo(39273791),
  autumn: photo(38808697),
  columns: photo(38906552),
  mexico: photo(37665469),
  bwurban: photo(15761494),
  yellow: photo(33218901),
  bwmodel: photo(33404920),
  sunglasses: photo(25797358),
  couple: photo(25797374),
  smile: photo(25797366),
  elderly: photo(16971836),
  friends: photo(13466147),
  backpack: photo(10426379),
  indoor: photo(12168498),
  makeup: photo(10125599),
  afro: photo(7982896),
  soft: photo(36076833),
  dance: photo(35774745, true),
  silhouette: photo(31633212, true),
  malibu: photo(33381356, true),
  hcmc: photo(35870740, true),
  linen: photo(18221948, true),
  cafe: photo(18405036, true),
  cafewin: photo(39784765, true),
  cafelamp: photo(34206672, true),
  cafeempty: photo(12570668, true),
  phone1: photo(8533225),
  phone2: photo(839443),
  phone3: photo(8970661),
  phone4: photo(8533737),
  walkPoster:
    "https://images.pexels.com/videos/18156295/pexels-photo-18156295.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1500&w=1100",
  walkVideo: "https://videos.pexels.com/video-files/18156295/18156295-hd_1080_1920_25fps.mp4",
  beachPoster:
    "https://images.pexels.com/videos/5418390/4k50fps-above-sea-beautiful-girl-beautiful-sunset-5418390.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1600",
  beachVideo: "https://videos.pexels.com/video-files/5418390/5418390-uhd_3840_2160_25fps.mp4",
};

function codeFor(seed: string) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let h = 0;
  for (const c of seed) h = (h * 33 + c.charCodeAt(0)) >>> 0;
  let out = "";
  for (let i = 0; i < 11; i++) {
    out += alphabet[h % alphabet.length];
    h = (h * 1664525 + 1013904223) >>> 0;
  }
  return out;
}

type Seed = {
  id: string;
  account: string;
  src: string;
  video?: string;
  wide?: boolean;
  ago: number;
  local?: boolean;
  kind?: Frame["kind"];
  slides?: string[];
  tags: [string, string, string, string, string];
  conf?: [number, number, number];
  caption: string;
  sig?: number;
  focus?: string;
  path?: string;
};

function make(s: Seed): Frame {
  const sig = s.sig ?? 0.52;
  return {
    id: s.id,
    account: s.account,
    src: s.src,
    video: s.video,
    wide: s.wide,
    date: s.local ? null : daysAgo(s.ago),
    code: s.local ? null : codeFor(s.id),
    kind: s.kind ?? "photo",
    slides: s.slides ?? [s.src],
    tags: {
      setting: s.tags[0],
      outfit: s.tags[1],
      shot: s.tags[2],
      pose: s.tags[3],
      arms: s.tags[4],
    },
    conf: {
      setting: s.conf?.[0] ?? 0.88,
      outfit: s.conf?.[1] ?? 0.84,
      shot: s.conf?.[2] ?? 0.8,
    },
    caption: s.caption,
    local: !!s.local,
    sig,
    clip: Math.min(0.93, Math.max(0.22, 1.02 - sig * 0.85)),
    focus: s.focus ?? "50% 28%",
    path: s.path,
  };
}

const M = MEDIA;

export const INITIAL_FRAMES: Frame[] = [
  make({
    id: "f-linen",
    account: "saltandfilm",
    src: M.linen,
    wide: true,
    ago: 16,
    tags: ["beach", "dress", "full", "standing", "at sides"],
    caption: "linen dress in late sun, looking away from the lens",
    sig: 0.71,
    focus: "50% 40%",
  }),
  make({
    id: "f-wind",
    account: "saltandfilm",
    src: M.beachPoster,
    video: M.beachVideo,
    wide: true,
    ago: 22,
    kind: "reel",
    tags: ["beach", "dress", "full", "standing", "raised"],
    caption: "late sun on the water, dress caught in the wind",
    sig: 0.77,
  }),
  make({
    id: "f-malibu",
    account: "saltandfilm",
    src: M.malibu,
    wide: true,
    ago: 48,
    tags: ["beach", "dress", "full", "standing", "at sides"],
    caption: "golden hour at the shoreline, still dress, late light",
    sig: 0.64,
  }),
  make({
    id: "f-hcmc",
    account: "saltandfilm",
    src: M.hcmc,
    ago: 75,
    tags: ["beach", "casual", "three-quarter", "standing", "at sides"],
    caption: "quiet beach portrait, hair across the face",
    sig: 0.58,
  }),
  make({
    id: "f-sil",
    account: "saltandfilm",
    src: M.silhouette,
    wide: true,
    ago: 75,
    kind: "carousel",
    slides: [M.silhouette, M.malibu, M.linen],
    tags: ["beach", "dress", "wide", "standing", "at sides"],
    caption: "sunset figure at the waterline, three slides",
    sig: 0.61,
  }),
  make({
    id: "f-blazer",
    account: "luna.atelier",
    src: M.blazer,
    ago: 28,
    tags: ["street", "blazer", "three-quarter", "standing", "at sides"],
    caption: "tailored blazer on a quiet street, hands at her sides",
    sig: 0.69,
  }),
  make({
    id: "f-coat",
    account: "luna.atelier",
    src: M.autumn,
    ago: 11,
    tags: ["street", "coat", "full", "standing", "crossed"],
    caption: "coat at dusk, arms crossed, street lamps coming on",
    sig: 0.66,
  }),
  make({
    id: "f-columns",
    account: "luna.atelier",
    src: M.columns,
    ago: 60,
    kind: "carousel",
    slides: [M.columns, M.yellow, M.blazer],
    tags: ["street", "dress", "three-quarter", "leaning", "one raised"],
    caption: "dress against stone columns, one arm raised",
    sig: 0.63,
  }),
  make({
    id: "f-yellow",
    account: "luna.atelier",
    src: M.yellow,
    ago: 88,
    tags: ["street", "dress", "full", "walking", "at sides"],
    caption: "printed dress, glass reflection, walking the street",
    sig: 0.6,
  }),
  make({
    id: "f-mono",
    account: "luna.atelier",
    src: M.bwurban,
    ago: 210,
    tags: ["street", "monochrome", "full", "standing", "at sides"],
    conf: [0.8, 0.41, 0.77],
    caption: "monochrome full length against an urban wall",
    sig: 0.48,
  }),
  make({
    id: "f-studio",
    account: "luna.atelier",
    src: M.bwmodel,
    ago: 150,
    tags: ["studio", "monochrome", "close-up", "standing", "crossed"],
    caption: "studio monochrome, arms crossed, tight crop",
    sig: 0.57,
  }),
  make({
    id: "f-window",
    account: "luna.atelier",
    src: M.indoor,
    ago: 9,
    tags: ["indoor", "casual", "close-up", "seated", "at sides"],
    caption: "indoor close-up, soft window light, seated",
    sig: 0.62,
  }),
  make({
    id: "f-knit",
    account: "luna.atelier",
    src: M.makeup,
    ago: 40,
    tags: ["studio", "knit", "close-up", "seated", "raised"],
    conf: [0.9, 0.36, 0.7],
    caption: "studio knit, seated, hands raised near the face",
    sig: 0.5,
  }),
  make({
    id: "f-afro",
    account: "luna.atelier",
    src: M.afro,
    ago: 96,
    tags: ["indoor", "casual", "close-up", "seated", "crossed"],
    caption: "indoor portrait, arms crossed, even light",
    sig: 0.55,
  }),
  make({
    id: "f-soft",
    account: "luna.atelier",
    src: M.soft,
    ago: 14,
    tags: ["studio", "knit", "close-up", "seated", "at sides"],
    caption: "soft studio light, knit texture, seated",
    sig: 0.59,
  }),
  make({
    id: "f-cityreel",
    account: "luna.atelier",
    src: M.walkPoster,
    video: M.walkVideo,
    ago: 5,
    kind: "reel",
    tags: ["street", "casual", "three-quarter", "walking", "in pockets"],
    caption: "city street, casual, walking, hands in pockets",
    sig: 0.67,
    focus: "50% 20%",
  }),
  make({
    id: "f-sun",
    account: "northroom",
    src: M.sunglasses,
    ago: 19,
    tags: ["street", "casual", "three-quarter", "walking", "at sides"],
    caption: "sunglasses and a tank top, walking a busy street",
    sig: 0.64,
  }),
  make({
    id: "f-smile",
    account: "northroom",
    src: M.smile,
    ago: 33,
    tags: ["street", "casual", "close-up", "standing", "at sides"],
    caption: "close smile on a summer street",
    sig: 0.58,
  }),
  make({
    id: "f-friends",
    account: "northroom",
    src: M.friends,
    ago: 120,
    tags: ["street", "casual", "full", "walking", "at sides"],
    caption: "two friends walking a shopping street, full length",
    sig: 0.61,
  }),
  make({
    id: "f-couple",
    account: "northroom",
    src: M.couple,
    ago: 180,
    kind: "carousel",
    slides: [M.couple, M.friends, M.sunglasses],
    tags: ["street", "casual", "full", "walking", "at sides"],
    caption: "couple walking the city, candid full body",
    sig: 0.54,
  }),
  make({
    id: "f-elder",
    account: "northroom",
    src: M.elderly,
    ago: 420,
    tags: ["street", "coat", "full", "walking", "at sides"],
    caption: "coats, arm in arm, walking the street",
    sig: 0.49,
  }),
  make({
    id: "f-pack",
    account: "northroom",
    src: M.backpack,
    ago: 260,
    tags: ["street", "casual", "full", "walking", "in pockets"],
    conf: [0.86, 0.44, 0.79],
    caption: "backpack, grey tee, moody street, hands in pockets",
    sig: 0.46,
  }),
  make({
    id: "f-cafe",
    account: "northroom",
    src: M.cafe,
    wide: true,
    ago: 18,
    tags: ["cafe", "none", "wide", "none", "none"],
    caption: "cafe interior, afternoon window light, wide empty room",
    sig: 0.57,
    focus: "50% 50%",
  }),
  make({
    id: "f-seat",
    account: "northroom",
    src: M.cafewin,
    wide: true,
    ago: 7,
    tags: ["cafe", "casual", "detail", "seated", "at sides"],
    caption: "seated at a cafe window, cup on the table",
    sig: 0.68,
  }),
  make({
    id: "f-lamp",
    account: "northroom",
    src: M.cafelamp,
    ago: 52,
    kind: "carousel",
    slides: [M.cafelamp, M.cafewin, M.cafe],
    tags: ["cafe", "coat", "wide", "seated", "crossed"],
    caption: "sunset cafe, warm lamps, seated in the corner",
    sig: 0.6,
  }),
  make({
    id: "f-empty",
    account: "northroom",
    src: M.cafeempty,
    ago: 310,
    tags: ["cafe", "none", "wide", "none", "none"],
    caption: "empty coffee shop, wide morning light",
    sig: 0.43,
  }),
  make({
    id: "f-nature",
    account: "luna.atelier",
    src: M.stone,
    ago: 64,
    tags: ["nature", "dress", "full", "leaning", "at sides"],
    caption: "white dress, stone ledge, leaning into the trees",
    sig: 0.65,
  }),
  make({
    id: "f-local1",
    account: "desk.imports",
    src: M.indoor,
    ago: 0,
    local: true,
    tags: ["indoor", "casual", "close-up", "seated", "at sides"],
    caption: "imported reference, seated indoor portrait",
    path: "/Users/mira/Pictures/reference-pulls/IMG_2044.jpg",
    sig: 0.6,
  }),
  make({
    id: "f-local2",
    account: "desk.imports",
    src: M.soft,
    ago: 0,
    local: true,
    tags: ["studio", "knit", "close-up", "seated", "at sides"],
    caption: "imported studio frame, knit, soft light",
    path: "/Users/mira/Pictures/reference-pulls/IMG_2091.jpg",
    sig: 0.56,
  }),
  make({
    id: "f-local3",
    account: "desk.imports",
    src: M.cafewin,
    wide: true,
    ago: 0,
    local: true,
    tags: ["cafe", "casual", "detail", "seated", "at sides"],
    caption: "imported cafe window still, seated",
    path: "/Users/mira/Pictures/reference-pulls/cafe-window.jpg",
    sig: 0.63,
  }),
  make({
    id: "f-localv",
    account: "desk.imports",
    src: M.beachPoster,
    video: M.beachVideo,
    wide: true,
    ago: 0,
    local: true,
    kind: "reel",
    tags: ["beach", "dress", "full", "standing", "raised"],
    caption: "imported clip, beach dress, sampled frames",
    path: "/Users/mira/Movies/trip-clips/beach-dress.mov",
    sig: 0.7,
  }),
];

export const INITIAL_ACCOUNTS: Account[] = [
  {
    handle: "luna.atelier",
    kind: "instagram",
    photos: 428,
    reels: 36,
    carousels: 112,
    slidesIndexed: 86,
    slidesTotal: 112,
    pose: true,
    carouselDetected: true,
    models: { siglip: true, clip: true },
    prepared: daysAgo(2),
    libraryBuilt: true,
    cover: M.blazer,
  },
  {
    handle: "northroom",
    kind: "instagram",
    photos: 190,
    reels: 22,
    carousels: 40,
    slidesIndexed: 40,
    slidesTotal: 40,
    pose: true,
    carouselDetected: true,
    models: { siglip: true, clip: false },
    prepared: daysAgo(12),
    libraryBuilt: true,
    cover: M.sunglasses,
  },
  {
    handle: "saltandfilm",
    kind: "instagram",
    photos: 96,
    reels: 8,
    carousels: 15,
    slidesIndexed: 0,
    slidesTotal: 15,
    pose: false,
    carouselDetected: false,
    models: { siglip: true, clip: false },
    prepared: daysAgo(40),
    libraryBuilt: false,
    cover: M.linen,
  },
  {
    handle: "desk.imports",
    kind: "local",
    photos: 64,
    reels: 6,
    carousels: 0,
    slidesIndexed: 0,
    slidesTotal: 0,
    pose: true,
    carouselDetected: true,
    models: { siglip: true, clip: true },
    prepared: daysAgo(3),
    libraryBuilt: true,
    cover: M.cafe,
  },
];

export const INITIAL_SOURCES: Source[] = [
  {
    id: "src-pulls",
    name: "Reference pulls",
    path: "/Users/mira/Pictures/reference-pulls",
    kind: "images",
    indexed: 48,
    pending: 6,
    added: daysAgo(20),
    feeds: "desk.imports",
  },
  {
    id: "src-clips",
    name: "Trip clips",
    path: "/Users/mira/Movies/trip-clips",
    kind: "videos",
    indexed: 6,
    pending: 2,
    added: daysAgo(8),
    feeds: "desk.imports",
  },
  {
    id: "src-dumps",
    name: "Studio dumps",
    path: "/Users/mira/Desktop/studio-dumps",
    kind: "images",
    indexed: 16,
    pending: 0,
    added: daysAgo(45),
    feeds: "desk.imports",
  },
];

export const PILOT: PilotShot[] = [
  {
    id: "p1",
    screenshot: M.phone1,
    crop: M.stone,
    score: 0.91,
    file: "Screenshot 2026-03-02 at 10.14.02.png",
    person: true,
  },
  {
    id: "p2",
    screenshot: M.phone3,
    crop: M.indoor,
    score: 0.84,
    file: "Screenshot 2026-02-18 at 19.02.44.png",
    person: true,
  },
  {
    id: "p3",
    screenshot: M.phone4,
    crop: M.makeup,
    score: 0.76,
    file: "Screenshot 2026-01-09 at 08.41.12.png",
    person: true,
  },
  {
    id: "p4",
    screenshot: M.phone2,
    crop: M.soft,
    score: 0.63,
    file: "Screenshot 2025-12-14 at 16.22.03.png",
    person: true,
  },
  {
    id: "p5",
    screenshot: M.phone1,
    crop: M.afro,
    score: 0.57,
    file: "Screenshot 2025-11-30 at 11.05.47.png",
    person: true,
  },
  {
    id: "p6",
    screenshot: M.phone3,
    crop: M.cafe,
    score: 0.44,
    file: "Screenshot 2025-11-02 at 13.18.20.png",
    person: false,
  },
  {
    id: "p7",
    screenshot: M.phone4,
    crop: M.cafeempty,
    score: 0.28,
    file: "Screenshot 2025-10-21 at 09.44.11.png",
    person: false,
  },
  {
    id: "p8",
    screenshot: M.phone2,
    crop: M.cafelamp,
    score: 0.15,
    file: "Screenshot 2025-09-12 at 18.03.55.png",
    person: false,
  },
];

export const ARCHIVE = {
  cache: "3.7 GB",
  library: "14.8 GB",
  host: "127.0.0.1:8501",
};

export function stubAccount(handle: string): Account {
  return {
    handle,
    kind: "instagram",
    photos: 0,
    reels: 0,
    carousels: 0,
    slidesIndexed: 0,
    slidesTotal: 0,
    pose: false,
    carouselDetected: false,
    models: { siglip: false, clip: false },
    prepared: null,
    libraryBuilt: false,
    cover: M.blazer,
  };
}
