import { useEffect, useState } from "react";
import { formatDate, titleCase } from "../data";
import type { Scored } from "../search";
import { useDesk } from "../store";
import { cn } from "../utils/cn";
import { Check, Icon, Star } from "./ui";

function kindBit(item: Scored) {
  if (item.local && item.video) return "local clip";
  if (item.local) return "local";
  if (item.kind === "reel") return "reel";
  if (item.kind === "carousel") return `${item.slideIndex + 1}/${item.slides.length}`;
  return "photo";
}

export function FrameCard({
  item,
  index,
  selected,
  showSelect,
  saved,
  pool,
}: {
  item: Scored;
  index: number;
  selected?: boolean;
  showSelect?: boolean;
  saved?: boolean;
  pool?: Scored[];
}) {
  const desk = useDesk();
  const faved = desk.isFav(item.resultId) || desk.isFav(item.id);
  const open = () => {
    const items = pool && pool.length ? pool : [item];
    const at = items.findIndex((r) => r.resultId === item.resultId);
    desk.openSlides(items, at >= 0 ? at : 0);
  };
  return (
    <article className={cn("frame", item.wide && "wide", selected && "sel")}>
      {showSelect && (
        <button type="button" className="tick" aria-label={selected ? "Deselect frame" : "Select frame"} onClick={() => desk.toggleSelected(item.resultId)}>
          <Check />
        </button>
      )}
      <span className={cn("score-pill", item.score < 0.45 && "low")}>{item.score.toFixed(2)}</span>
      <button type="button" className="open" onClick={open}>
        <img src={item.src} alt={item.caption} style={{ objectPosition: item.focus }} />
        <span className="scrim" />
      </button>
      <span className="foot">
        {String(index + 1).padStart(2, "0")} · {kindBit(item)}
        {saved ? " · full" : ""} · {item.account}
      </span>
      <span className="cluster">
        <button
          type="button"
          className="fav"
          aria-label={item.local ? "Show in Finder" : "Copy Instagram link"}
          onClick={() => (item.local && item.path ? desk.reveal(item.path) : desk.copyText(item.code ? `https://www.instagram.com/p/${item.code}/` : item.caption))}
        >
          <Icon name={item.local ? "folder" : "link"} size={14} />
        </button>
        <button
          type="button"
          className={cn("fav", faved && "on")}
          aria-label={faved ? "Remove favourite" : "Add favourite"}
          onClick={() => desk.toggleFav({ id: item.resultId, account: item.account, src: item.src, code: item.code, caption: item.caption })}
        >
          <Star filled={faved} />
        </button>
      </span>
    </article>
  );
}

export function ContactSheet({ items, showSelect }: { items: Scored[]; showSelect?: boolean }) {
  const desk = useDesk();
  return (
    <div className="sheet-wrap">
      <div className="sheet">
        {items.map((item, i) => (
          <FrameCard
            key={item.resultId}
            item={item}
            index={i}
            showSelect={showSelect}
            selected={desk.selectedIds.includes(item.resultId)}
            saved={desk.savedFull.includes(item.resultId)}
            pool={items}
          />
        ))}
      </div>
    </div>
  );
}

export function LinkList({ items }: { items: Scored[] }) {
  const desk = useDesk();
  return (
    <div className="list">
      {items.map((item) => (
        <article key={item.resultId} className="list-row">
          <img src={item.src} alt="" />
          <div>
            <h3>@{item.account}</h3>
            <p>{item.caption}</p>
            <p>
              {item.date ? formatDate(item.date) : "No post date"} · {kindBit(item)} · {item.score.toFixed(2)}
            </p>
          </div>
          <div className="row">
            <button type="button" className="btn tiny" onClick={() => desk.copyText(item.code ? `https://www.instagram.com/p/${item.code}/` : item.path || item.caption)}>
              {item.local ? "Path" : "Copy link"}
            </button>
            <button type="button" className="btn tiny" onClick={() => desk.toggleFav({ id: item.id, account: item.account, src: item.src, code: item.code, caption: item.caption })}>
              {desk.isFav(item.id) ? "Unfavourite" : "Favourite"}
            </button>
          </div>
        </article>
      ))}
    </div>
  );
}

export function Slideshow() {
  const desk = useDesk();
  const item: Scored | undefined = desk.slides.items[desk.slides.index];
  const [slide, setSlide] = useState(0);
  const [limitClip, setLimitClip] = useState(true);

  useEffect(() => {
    setSlide(item?.slideIndex || 0);
    setLimitClip(true);
  }, [item?.resultId, item?.slideIndex]);

  useEffect(() => {
    if (!desk.slides.open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") desk.closeSlides();
      if (e.key === "ArrowRight") desk.stepSlides(1);
      if (e.key === "ArrowLeft") desk.stepSlides(-1);
      if (e.key === "f" && item) {
        desk.toggleFav({ id: item.resultId, account: item.account, src: item.slides[slide] || item.src, code: item.code, caption: item.caption });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [desk, item, slide]);

  if (!desk.slides.open || !item) return null;
  const src = item.slides[slide] || item.src;
  const faved = desk.isFav(item.resultId) || desk.isFav(item.id);
  const link = item.code ? `https://www.instagram.com/p/${item.code}/` : null;

  return (
    <div className="slideshow" role="dialog" aria-label="Slideshow">
      <div className="slide-stage">
        <button type="button" className="slide-nav prev" aria-label="Previous" onClick={() => desk.stepSlides(-1)}>←</button>
        {item.video && slide === 0 ? (
          <video
            key={item.resultId + String(limitClip)}
            src={item.video}
            poster={src}
            controls
            autoPlay
            playsInline
            onTimeUpdate={(e) => {
              const v = e.currentTarget;
              if (item.local && limitClip && v.currentTime >= desk.clipLength) v.pause();
            }}
          />
        ) : (
          <img src={src} alt={item.caption} />
        )}
        <button type="button" className="slide-nav next" aria-label="Next" onClick={() => desk.stepSlides(1)}>→</button>
      </div>
      <aside className="slide-meta">
        <div className="spread">
          <p className="kicker">{String(desk.slides.index + 1).padStart(2, "0")} / {String(desk.slides.items.length).padStart(2, "0")}</p>
          <button type="button" className="icon-btn" onClick={desk.closeSlides} aria-label="Close slideshow"><Icon name="x" /></button>
        </div>
        <h2 style={{ fontSize: 32, marginTop: 8 }}>{item.score.toFixed(2)}</h2>
        <div className="score-bar"><i style={{ width: `${Math.round(item.score * 100)}%` }} /></div>
        <p className="hint">{item.caption}</p>
        <p className="hint" style={{ marginTop: 8 }}>
          @{item.account} · {item.date ? formatDate(item.date) : "Local file, no post date"} · {kindBit(item)}
        </p>
        <div className="chips" style={{ marginTop: 12 }}>
          {(Object.entries(item.tags) as [string, string][])
            .filter(([, tag]) => tag !== "none")
            .map(([group, tag]) => (
              <span key={group} className="chip">{titleCase(tag)}</span>
            ))}
        </div>
        <p className="hint" style={{ marginTop: 10 }}>
          Tag confidence · setting {item.conf.setting.toFixed(2)} · outfit {item.conf.outfit.toFixed(2)} · shot {item.conf.shot.toFixed(2)}. Pose and arms are coarser classes.
        </p>
        {item.slides.length > 1 && (
          <div className="film">
            {item.slides.map((s: string, i: number) => (
              <button type="button" key={s + i} className={i === slide ? "on" : ""} onClick={() => setSlide(i)} aria-label={`Slide ${i + 1}`}>
                <img src={s} alt="" />
              </button>
            ))}
          </div>
        )}
        {item.video && item.local && (
          <div className="section">
            <ToggleLine on={limitClip} label={`Cut playback at ${desk.clipLength.toFixed(1)}s`} onClick={() => setLimitClip((v) => !v)} />
            <p className="hint">Imported clips are cut on demand. Instagram reels play in full.</p>
          </div>
        )}
        {item.video && !item.local && <p className="hint" style={{ marginTop: 10 }}>Reel · clip length applies to imported video, not this post.</p>}
        <div className="row" style={{ marginTop: 16 }}>
          <button type="button" className={cn("btn tiny", faved && "gold")} onClick={() => desk.toggleFav({ id: item.resultId, account: item.account, src, code: item.code, caption: item.caption })}>
            <Star filled={faved} /> {faved ? "Favourited" : "Favourite"}
          </button>
          <button type="button" className="btn tiny" onClick={() => desk.toast(`Saved ${item.code || item.id}.jpg to picks/`)}>
            Download
          </button>
          {link ? (
            <button type="button" className="btn tiny" onClick={() => desk.copyText(link)}>Copy link</button>
          ) : (
            <button type="button" className="btn tiny" onClick={() => desk.reveal(item.path || `imports/${item.account}`)}>Finder</button>
          )}
        </div>
        <p className="hint" style={{ marginTop: 18 }}>← → frames · F favourite · Esc close</p>
      </aside>
    </div>
  );
}

function ToggleLine({ on, label, onClick }: { on: boolean; label: string; onClick: () => void }) {
  return (
    <button type="button" className={cn("toggle", on && "on")} onClick={onClick}>
      <span className="track"><span className="knob" /></span>
      <span><strong>{label}</strong></span>
    </button>
  );
}
