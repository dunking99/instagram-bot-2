import { useState } from "react";
import { GROUP_LABEL, MEDIA, MODEL_TAGS, TAGS, titleCase, type TagGroup } from "../data";
import { useDesk } from "../store";
import { cn } from "../utils/cn";
import { ContactSheet, LinkList } from "./Frames";
import { Icon, Seg } from "./ui";

function readImage(file: File, set: (url: string) => void) {
  if (!file.type.startsWith("image/")) return;
  const reader = new FileReader();
  reader.onload = () => set(String(reader.result));
  reader.readAsDataURL(file);
}

function Drop({
  image,
  label,
  onFile,
  onClear,
}: {
  image: string | null;
  label: string;
  onFile: (file: File) => void;
  onClear: () => void;
}) {
  return (
    <div
      className={cn("drop", image && "has")}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        const file = e.dataTransfer.files?.[0];
        if (file) onFile(file);
      }}
    >
      {image && <img src={image} alt="" />}
      <span className="drop-ui">
        <label>
          {label}
          <input type="file" accept="image/*" hidden onChange={(e) => { const file = e.target.files?.[0]; if (file) onFile(file); }} />
        </label>
        {image && (
          <button type="button" className="btn tiny" style={{ marginTop: 8 }} onClick={onClear}>
            Remove
          </button>
        )}
      </span>
    </div>
  );
}

export function SearchView() {
  const d = useDesk();
  const [tagsOpen, setTagsOpen] = useState(d.tags.length > 0);
  const [draft, setDraft] = useState("");
  const hasSignal = (d.useText && d.text.trim()) || (d.useImage && d.refImage) || (d.usePose && d.poseImage) || d.tags.length > 0;
  const both = d.useText && d.text.trim() && d.useImage && d.refImage;
  const picks = (d.frames as { account: string; src: string; id: string }[])
    .filter((f) => d.selectedAccounts.includes(f.account))
    .slice(0, 8);
  const pool = picks.length ? picks : d.frames.slice(0, 8);
  const missing = d.selectedAccounts.filter((h: string) => !d.accounts.find((a: { handle: string; models: { siglip: boolean; clip: boolean } }) => a.handle === h)?.models[d.model]);
  const sameGroup = (Object.keys(TAGS) as TagGroup[]).some((g) => d.tags.filter((t: { group: string }) => t.group === g).length > 1);

  const suggest = (text: string, selected: string[]) => {
    d.find({ text, selected, useText: true, useImage: false, usePose: false, tags: [] });
  };

  return (
    <div>
      {d.results == null && !d.searching && (
        <header className="search-intro">
          <p className="kicker">Search desk</p>
          <h1>Find a frame in the index.</h1>
          <p className="lede">
            Describe a scene, drop a reference, match a pose, or require tags. Postroom ranks the saved index — thumbnails, full files, or links.
          </p>
        </header>
      )}

      {!d.sessionOk && (
        <div className="banner">
          <p>Instagram session missing. Cached indexes still search. Refresh, rebuild, and new accounts need a login.</p>
          <button type="button" className="btn tiny" onClick={() => d.setSessionOpen(true)}>Session</button>
        </div>
      )}

      <section className={cn("composer", !d.composerOpen && "slim")}>
        {!d.composerOpen ? (
          <div className="slim">
            <div>
              <strong>{d.lastSummary || "Last search"}</strong>
              <span>{d.results ? `${d.results.length} frames` : "No cut yet"} · {d.model}</span>
            </div>
            <div className="row">
              <button type="button" className="btn tiny" onClick={() => d.setComposerOpen(true)}>Edit</button>
              <button type="button" className="btn primary" onClick={() => d.find()} disabled={d.searching}>Run again</button>
            </div>
          </div>
        ) : (
          <>
            <div className="spread">
              <p className="kicker" style={{ margin: 0 }}>Accounts</p>
              <button type="button" className="btn tiny" onClick={() => d.setPrepareFor("")}>Prepare indexes</button>
            </div>
            <div className="acct-row" style={{ marginTop: 8 }}>
              {d.accounts.map((a: { handle: string; cover: string; models: { siglip: boolean; clip: boolean } }) => {
                const on = d.selectedAccounts.includes(a.handle);
                const ready = a.models[d.model as "siglip" | "clip"];
                return (
                  <button key={a.handle} type="button" className={cn("acct", on && "on")} onClick={() => d.toggleAccount(a.handle)} aria-pressed={on}>
                    <img src={a.cover} alt="" />
                    <span>@{a.handle}</span>
                    {!ready && <i className="mini-dot" title={`No ${d.model} index`} />}
                  </button>
                );
              })}
              <form className="acct-add" onSubmit={(e) => { e.preventDefault(); d.addAccount(draft); setDraft(""); }}>
                <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Add @handle" aria-label="Add account" />
                <button type="submit" aria-label="Add account"><Icon name="plus" size={14} /></button>
              </form>
            </div>

            <div className={cn("query", !d.useText && "off")}>
              <textarea
                id="query"
                value={d.text}
                onChange={(e) => d.setText(e.target.value)}
                placeholder={d.useText ? "Describe the frame you want…" : "Text ranking is off"}
                rows={2}
                readOnly={!d.useText}
              />
            </div>
            <div className="signals">
              <button type="button" className={cn("signal", d.useText && "on")} onClick={() => d.setUseText(!d.useText)}>Scene text</button>
              <button type="button" className={cn("signal", d.useImage && "on")} onClick={() => d.setUseImage(!d.useImage)}>Reference</button>
              <button type="button" className={cn("signal", d.usePose && "on")} onClick={() => d.setUsePose(!d.usePose)}>Pose</button>
            </div>

            {d.useImage && (
              <div className="drop-grid">
                <Drop
                  image={d.refImage}
                  label="Drop a reference, or pick a frame"
                  onFile={(f) => readImage(f, d.setRefImage)}
                  onClear={() => d.setRefImage(null)}
                />
                <div>
                  <p className="hint">Likeness uses the image index. If the frame is already saved, it should rise to the top.</p>
                  <div className="pick-row">
                    {pool.map((frame: { id: string; src: string }) => (
                      <button type="button" key={frame.id} onClick={() => d.setRefImage(frame.src)} aria-label="Use as reference">
                        <img src={frame.src} alt="" />
                      </button>
                    ))}
                  </div>
                  {both && (
                    <div className="weight">
                      <div className="ends">
                        <span>Text {Math.round((1 - d.imageWeight) * 100)}</span>
                        <span>Image {Math.round(d.imageWeight * 100)}</span>
                      </div>
                      <input type="range" min={0} max={1} step={0.05} value={d.imageWeight} onChange={(e) => d.setImageWeight(Number(e.target.value))} aria-label="Text and image weight" />
                    </div>
                  )}
                </div>
              </div>
            )}

            {d.usePose && (
              <div className="drop-grid">
                <Drop
                  image={d.poseImage}
                  label="Drop a pose reference"
                  onFile={(f) => readImage(f, d.setPoseImage)}
                  onClear={() => d.setPoseImage(null)}
                />
                <div className="stack">
                  <button type="button" className={cn("toggle", d.mirrorPose && "on")} onClick={() => d.setMirrorPose(!d.mirrorPose)}>
                    <span className="track"><span className="knob" /></span>
                    <span>
                      <strong>Treat mirrored poses as matches</strong>
                      <small>Unusual angles are less reliable. Scene text above can still steer the rank.</small>
                    </span>
                  </button>
                  <p className="hint warn">Accounts without a pose index are skipped. Build one from Library if a name drops out.</p>
                  <div className="pick-row">
                    {pool.map((frame: { id: string; src: string }) => (
                      <button type="button" key={`p-${frame.id}`} onClick={() => d.setPoseImage(frame.src)} aria-label="Use as pose">
                        <img src={frame.src} alt="" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="tag-block">
              <button type="button" className="spread" onClick={() => setTagsOpen((v) => !v)} style={{ width: "100%", background: "none", border: 0, color: "inherit", padding: 0 }}>
                <span className="kicker" style={{ margin: 0 }}>Must match</span>
                <span className="hint">{d.tags.length ? `${d.tags.length} tags · all required` : "Tags optional"}</span>
              </button>
              {!!d.tags.length && (
                <div className="chips" style={{ marginTop: 8 }}>
                  {d.tags.map((t: { group: string; tag: string }) => (
                    <button type="button" key={`${t.group}-${t.tag}`} className="chip on" onClick={() => d.toggleTag(t.group, t.tag)}>
                      {t.tag} ×
                    </button>
                  ))}
                  <button type="button" className="chip ghost" onClick={() => d.setTags([])}>Clear</button>
                </div>
              )}
              {tagsOpen && (
                <div className="tag-groups">
                  {(Object.keys(TAGS) as TagGroup[]).map((g) => (
                    <div key={g}>
                      <div className="tag-label">{GROUP_LABEL[g]}{MODEL_TAGS.includes(g) ? "" : " · not gated by confidence"}</div>
                      <div className="chips">
                        {TAGS[g].map((tag) => (
                          <button
                            type="button"
                            key={tag}
                            className={cn("chip", d.tags.some((t: { group: string; tag: string }) => t.group === g && t.tag === tag) && "on")}
                            onClick={() => d.toggleTag(g, tag)}
                          >
                            {titleCase(tag)}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                  {sameGroup && <p className="hint warn">Two tags in one group almost never match — a frame has a single setting, outfit, shot, pose, and arms class.</p>}
                  {!!d.tags.length && (
                    <label className="field">
                      <span>Confidence · {d.confidence.toFixed(2)} · setting, outfit, shot only</span>
                      <input type="range" min={0.3} max={0.95} step={0.01} value={d.confidence} onChange={(e) => d.setConfidence(Number(e.target.value))} />
                    </label>
                  )}
                </div>
              )}
            </div>

            {!!missing.length && (
              <p className="hint warn" style={{ marginTop: 10 }}>
                No {d.model.toUpperCase()} index for {missing.map((h: string) => `@${h}`).join(", ")}. Prepare it, or the first search on that model can take several minutes.
              </p>
            )}

            <FilterChips />

            <div className="footbar">
              <Seg
                label="Result mode"
                value={d.resultMode}
                onChange={d.setResultMode}
                options={[{ id: "thumbs", label: "Thumbs" }, { id: "full", label: "Full size" }, { id: "links", label: "Links" }]}
              />
              <div className="row">
                <Seg label="Polarity" value={d.polarity} onChange={d.setPolarity} options={[{ id: "best", label: "Best" }, { id: "worst", label: "Worst" }]} />
                <select className="quiet" value={d.takeAll ? "all" : String(d.count)} onChange={(e) => {
                  if (e.target.value === "all") d.setTakeAll(true);
                  else { d.setTakeAll(false); d.setCount(Number(e.target.value)); }
                }} aria-label="Result count">
                  {[8, 12, 24, 48].map((n) => <option key={n} value={n}>{n}</option>)}
                  <option value="all">All ≤ {d.cap}</option>
                </select>
                <Seg label="Account mixing" value={d.mix} onChange={d.setMix} options={[{ id: "pool", label: "Pool" }, { id: "spread", label: "Spread" }]} />
              </div>
              <div className="row">
                <button type="button" className="btn" onClick={() => d.setRefineOpen(true)}>Refine</button>
                {d.searching ? (
                  <button type="button" className="btn danger" onClick={d.cancelFind}>Cancel</button>
                ) : (
                  <button type="button" className="btn primary" onClick={() => d.find()}>{hasSignal ? "Find posts" : "Draw random"}</button>
                )}
              </div>
            </div>
          </>
        )}
      </section>

      {(d.searching || d.logs.length > 0) && (
        <div className="log">
          <button type="button" onClick={() => d.setShowLog(!d.showLog)}>
            <span>{d.searching ? "Running random_post.py" : "Search log"}</span>
            <span className="mono">{d.logs[d.logs.length - 1]}</span>
          </button>
          {(d.showLog || d.searching) && <pre>{d.logs.join("\n")}</pre>}
        </div>
      )}

      {d.searching && (
        <div className="sheet-wrap" style={{ marginTop: 16 }}>
          <div className="sheet">
            {Array.from({ length: 8 }).map((_, i) => <div key={i} className="skel" />)}
          </div>
        </div>
      )}

      {!d.searching && d.results && <Results />}

      {!d.searching && d.results == null && (
        <>
          <div className="suggest">
            <button type="button" onClick={() => suggest("linen dress, late sun, looking away", ["luna.atelier", "saltandfilm"])}>
              <article>
                <img src={MEDIA.linen} alt="" />
                <div>
                  <span>Suggested</span>
                  <strong>Linen, late sun, looking away</strong>
                </div>
              </article>
            </button>
            <button type="button" onClick={() => suggest("cafe window, seated", ["northroom"])}>
              <article>
                <img src={MEDIA.cafewin} alt="" />
                <div>
                  <span>Suggested</span>
                  <strong>Cafe window, seated</strong>
                </div>
              </article>
            </button>
            <button type="button" onClick={() => suggest("full body walking street", ["luna.atelier", "northroom"])}>
              <article>
                <img src={MEDIA.sunglasses} alt="" />
                <div>
                  <span>Suggested</span>
                  <strong>Walking the street</strong>
                </div>
              </article>
            </button>
          </div>
          <p className="hint" style={{ marginTop: 12 }}>
            Empty query draws at random from the indexed pool. Scores are similarities, not proof.
          </p>
        </>
      )}
    </div>
  );
}

function FilterChips() {
  const d = useDesk();
  const chips: { label: string; clear: () => void }[] = [];
  if (d.dateFrom || d.dateTo) chips.push({ label: `${d.dateFrom || "…"} → ${d.dateTo || "…"}`, clear: () => { d.setDateFrom(""); d.setDateTo(""); } });
  if (d.includeVideo) chips.push({ label: `Videos · ${d.clipLength}s clips`, clear: () => d.setIncludeVideo(false) });
  if (d.carouselMode !== "cover") chips.push({ label: d.carouselMode === "all" ? "Every slide" : "Index carousels", clear: () => d.setCarouselMode("cover") });
  if (d.cacheMode !== "cache") chips.push({ label: d.cacheMode === "refresh" ? "Check for new posts" : "Rebuild cache", clear: () => d.setCacheMode("cache") });
  if (d.takeAll) chips.push({ label: `All ≤ ${d.cap}`, clear: () => d.setTakeAll(false) });
  if (!chips.length) return null;
  return (
    <div className="filters">
      {chips.map((c) => (
        <button type="button" key={c.label} className="chip on" onClick={c.clear}>{c.label} ×</button>
      ))}
    </div>
  );
}

function Results() {
  const d = useDesk();
  const items = d.results || [];
  const meta = d.runMeta;
  const selected = items.filter((r: { resultId: string }) => d.selectedIds.includes(r.resultId));
  return (
    <div>
      <div className="results-head">
        <div>
          <h2>{items.length} frame{items.length === 1 ? "" : "s"}</h2>
          <p>
            {meta?.mode === "random"
              ? "Random draw from the indexed pool. Best and worst do not apply."
              : meta?.polarity === "worst"
                ? "Lowest scores — for inspecting the ranker, not a recommendation."
                : "Highest scores in this cut. A score is a similarity, not a label of truth."}
            {meta?.excludedLocal ? ` ${meta.excludedLocal} local files were hidden by the date filter.` : ""}
            {meta?.skippedPose?.length ? ` Pose skipped ${meta.skippedPose.map((h: string) => "@" + h).join(", ")}.` : ""}
            {meta?.carouselMode === "index" ? " Promising carousels can be indexed from Library." : ""}
          </p>
        </div>
        {d.resultMode === "thumbs" && items.length > 0 && (
          <div className="row">
            <button type="button" className="btn tiny" onClick={() => d.setSelectedIds(items.map((r: { resultId: string }) => r.resultId))}>Select all</button>
            <button type="button" className="btn tiny" onClick={() => d.setSelectedIds([])}>Select none</button>
          </div>
        )}
      </div>
      {items.length === 0 ? (
        <div className="empty">
          <h2>Nothing in this cut.</h2>
          <p className="hint">Tags may be too strict, confidence may be high, a date filter may have hidden local files, or the account has no index for this model.</p>
          <div className="row" style={{ marginTop: 12 }}>
            <button type="button" className="btn tiny" onClick={() => d.find({ tags: [], dateFrom: "", dateTo: "" })}>Clear tags and dates</button>
            <button type="button" className="btn tiny" onClick={() => d.setPrepareFor(d.selectedAccounts[0] || "")}>Prepare account</button>
          </div>
        </div>
      ) : d.resultMode === "links" ? (
        <LinkList items={items} />
      ) : (
        <>
          {d.resultMode === "full" && <p className="hint" style={{ marginBottom: 8 }}>Full-size files landed in picks/. Links back to Instagram are on each frame.</p>}
          <ContactSheet items={items} showSelect={d.resultMode === "thumbs"} />
        </>
      )}
      {d.resultMode === "thumbs" && items.length > 0 && (
        <div className="dock">
          <span className="count">{selected.length} selected</span>
          <button type="button" className="btn tiny" disabled={!selected.length} onClick={() => d.openSlides(selected, 0)}>Slideshow</button>
          <button type="button" className="btn tiny" disabled={!selected.length} onClick={() => d.saveSelected("thumbs")}>Save thumbnails</button>
          <button type="button" className="btn tiny" disabled={!selected.length} onClick={() => d.saveSelected("full")}>Fetch full size</button>
          <button type="button" className="btn tiny" disabled={!selected.length} onClick={() => {
            const fresh = selected.filter((r: { resultId: string }) => !d.isFav(r.resultId));
            fresh.forEach((r: { resultId: string; account: string; src: string; code: string | null; caption: string }) => d.toggleFav({ id: r.resultId, account: r.account, src: r.src, code: r.code, caption: r.caption }, true));
            d.toast(fresh.length ? `Copied ${fresh.length} to favourites/` : "Already in favourites");
          }}>Favourite</button>
        </div>
      )}
    </div>
  );
}
