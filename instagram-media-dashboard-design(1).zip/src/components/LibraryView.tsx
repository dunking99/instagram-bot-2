import { useState } from "react";
import { GROUP_LABEL, TAGS, formatDate, titleCase, type Frame, type TagGroup } from "../data";
import type { Scored } from "../search";
import { useDesk } from "../store";
import { cn } from "../utils/cn";
import { ContactSheet } from "./Frames";
import { Modal, Seg } from "./ui";

function asScored(f: Frame): Scored {
  return { ...f, score: f.sig, slideIndex: 0, resultId: f.id };
}

export function LibraryView() {
  const d = useDesk();
  const account = d.accounts.find((a: { handle: string }) => a.handle === d.libraryAccount) || d.accounts[0];
  const mine = (d.frames as Frame[]).filter((f) => f.account === account.handle);
  const counts: Record<TagGroup, Record<string, number>> = { setting: {}, outfit: {}, shot: {}, pose: {}, arms: {} };
  for (const f of mine) {
    (Object.keys(counts) as TagGroup[]).forEach((g) => {
      const tag = f.tags[g];
      if (!tag || tag === "none") return;
      counts[g][tag] = (counts[g][tag] || 0) + 1;
    });
  }
  const matching = mine.filter((f) => d.picked.every((t: { group: TagGroup; tag: string }) => f.tags[t.group] === t.tag));
  const shown = matching.slice(0, d.galleryLimit).map(asScored);
  const total = account.photos + account.reels + account.carousels || 1;
  const [workers, setWorkers] = useState(1);
  const [batch, setBatch] = useState(25);
  const [until, setUntil] = useState(false);
  const [tree, setTree] = useState(false);
  const running = d.jobs.find((j: { account?: string; status: string }) => j.account === account.handle && j.status === "running");
  const ready = account.models[d.model as "siglip" | "clip"];

  return (
    <div>
      <p className="kicker">Library</p>
      <div className="spread">
        <h1 style={{ fontSize: "clamp(32px, 4vw, 48px)" }}>What’s in the index.</h1>
        <div className="row">
          <button type="button" className="btn" onClick={() => d.setPrepareFor(account.handle)}>Prepare</button>
          <button type="button" className="btn" onClick={() => setTree(true)}>{account.libraryBuilt ? "Open library" : "Preview folders"}</button>
        </div>
      </div>
      <div className="acct-row" style={{ marginTop: 16 }}>
        {d.accounts.map((a: { handle: string; cover: string }) => (
          <button key={a.handle} type="button" className={cn("acct", a.handle === account.handle && "on")} onClick={() => { d.setLibraryAccount(a.handle); d.clearPicked(); }}>
            <img src={a.cover} alt="" />
            @{a.handle}
          </button>
        ))}
      </div>

      <div className="stats">
        <div className="stat"><b>{account.photos}</b><span>Photo posts</span></div>
        <div className="stat"><b>{account.reels}</b><span>Reels</span></div>
        <div className="stat"><b>{account.carousels}</b><span>Carousels</span></div>
        <div className="stat"><b>{account.slidesIndexed}<span style={{ fontSize: 16, color: "var(--dust)" }}>/{account.slidesTotal || 0}</span></b><span>Indexed slides</span></div>
      </div>
      <div className="meter" aria-hidden>
        <i style={{ width: `${(account.photos / total) * 100}%` }} />
        <i style={{ width: `${(account.reels / total) * 100}%` }} />
        <i style={{ width: `${(account.carousels / total) * 100}%` }} />
      </div>
      <p className="hint" style={{ margin: "8px 0 16px" }}>
        {ready ? `${d.model.toUpperCase()} index` : `No ${d.model.toUpperCase()} index`}
        {account.prepared ? ` · prepared ${formatDate(account.prepared)}` : " · not prepared"}
        {account.pose ? " · pose ready" : " · pose missing"}
        {" · "}working set on this desk: {mine.length} frames
      </p>

      {running && (
        <div className="callout">
          <p>{running.title} · {Math.round(running.progress)}%</p>
          <button type="button" className="btn tiny" onClick={() => d.setJobsOpen(true)}>Show job</button>
        </div>
      )}

      {!account.carouselDetected && account.kind === "instagram" && (
        <div className="callout">
          <p>Carousel types aren’t detected yet, so slide counts are incomplete.</p>
          <button type="button" className="btn tiny" onClick={() => d.startDetect(account.handle)}>Detect carousels</button>
        </div>
      )}
      {!account.pose && (
        <div className="callout">
          <p>No pose index. Pose search will skip @{account.handle}.</p>
          <button type="button" className="btn tiny" onClick={() => d.startPose(account.handle)}>Build pose index</button>
        </div>
      )}

      {account.carouselDetected && account.slidesTotal > account.slidesIndexed && (
        <div className="panel" style={{ padding: 14, borderRadius: 16, border: "1px solid var(--line)", marginBottom: 14 }}>
          <div className="spread">
            <div>
              <p className="kicker">Index every image</p>
              <h3>{account.slidesIndexed} of {account.slidesTotal} slides</h3>
            </div>
            <Seg label="Workers" value={String(workers)} onChange={(v) => setWorkers(Number(v))} options={[{ id: "1", label: "1" }, { id: "2", label: "2" }, { id: "3", label: "3" }]} />
          </div>
          <div className="progress" style={{ margin: "10px 0" }}><i style={{ width: `${(account.slidesIndexed / account.slidesTotal) * 100}%` }} /></div>
          <div className="row">
            <Seg label="Batch" value={until ? "all" : String(batch)} onChange={(v) => { if (v === "all") setUntil(true); else { setUntil(false); setBatch(Number(v)); } }} options={[{ id: "25", label: "25" }, { id: "50", label: "50" }, { id: "all", label: "Until done" }]} />
            <button type="button" className="btn primary" onClick={() => d.startIndex(account.handle, workers, until, batch)}>Index slides</button>
          </div>
          {workers > 1 && <p className="hint warn" style={{ marginTop: 8 }}>More workers increase Instagram page loads and the chance of a rate limit.</p>}
        </div>
      )}

      <div className="split">
        <aside className="tag-col">
          {(Object.keys(TAGS) as TagGroup[]).map((g) => (
            <div key={g} style={{ marginBottom: 14 }}>
              <div className="tag-label">{GROUP_LABEL[g]}</div>
              {TAGS[g].map((tag) => {
                const n = counts[g][tag] || 0;
                if (!n) return null;
                const on = d.picked.some((t: { group: string; tag: string }) => t.group === g && t.tag === tag);
                const max = Math.max(1, ...Object.values(counts[g]));
                return (
                  <button type="button" key={tag} className={cn("count-line", on && "on")} onClick={() => d.pickTag(g, tag)}>
                    <span><i className="bar" style={{ width: 8 + (n / max) * 42 }} />{titleCase(tag)}</span>
                    <em>{n}</em>
                  </button>
                );
              })}
            </div>
          ))}
          <p className="hint">A second tag from another group asks whether to show it alone or require both.</p>
        </aside>
        <div>
          <div className="spread" style={{ marginBottom: 10 }}>
            <div>
              <h2 style={{ fontSize: 26 }}>{d.picked.length ? d.picked.map((t: { tag: string }) => titleCase(t.tag)).join(" + ") : "Recent frames"}</h2>
              <p className="hint">{matching.length} in the working set{d.picked.length ? " · all selected tags required" : ""}</p>
            </div>
            {!!d.picked.length && <button type="button" className="btn tiny" onClick={d.clearPicked}>Clear</button>}
          </div>
          {shown.length ? <ContactSheet items={shown} /> : <div className="empty"><h2>No frames for that combination.</h2></div>}
          {matching.length > shown.length && (
            <button type="button" className="btn" style={{ marginTop: 12 }} onClick={() => d.setGalleryLimit(d.galleryLimit + 8)}>Show more</button>
          )}
        </div>
      </div>

      {d.pendingTag && (
        <Modal kicker="Combine tags" title={`Add ${d.pendingTag.tag}?`} onClose={() => d.setPendingTag(null)}>
          <p className="hint">
            {d.picked.map((t: { tag: string }) => titleCase(t.tag)).join(" + ")} is already selected. Show {d.pendingTag.tag} alone, or require both.
          </p>
          <div className="row" style={{ marginTop: 16 }}>
            <button type="button" className="btn" onClick={() => d.resolvePending("alone")}>Show {d.pendingTag.tag} alone</button>
            <button type="button" className="btn primary" onClick={() => d.resolvePending("both")}>Require both</button>
          </div>
        </Modal>
      )}

      {tree && (
        <Modal kicker={`library/${account.handle}`} title={account.libraryBuilt ? "Categorized folders" : "Not written yet"} onClose={() => setTree(false)} wide>
          <p className="hint" style={{ marginBottom: 12 }}>
            {account.libraryBuilt
              ? "Folders were built from the tag pass. This is the working-set preview."
              : "Rebuild writes library folders and a manifest. The preview below is what that pass would file."}
          </p>
          <div className="tree">
            <b>library/{account.handle}/</b>
            {(Object.keys(counts) as TagGroup[]).map((g) => (
              <div key={g}>
                <b>  {g}/</b>
                {Object.entries(counts[g]).map(([tag, n]) => (
                  <div key={tag}>    {tag}/ · {n}</div>
                ))}
              </div>
            ))}
          </div>
          <div className="row" style={{ marginTop: 16 }}>
            <button type="button" className="btn" onClick={() => d.reveal(`library/${account.handle}`)}>Show in Finder</button>
            <button type="button" className="btn primary" onClick={() => { d.startLibrary(account.handle); setTree(false); }}>Rebuild library</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
