import { useState } from "react";
import { PILOT, type PilotShot } from "../data";
import { useDesk, type Pile } from "../store";
import { cn } from "../utils/cn";

const PILES: { id: Pile; label: string; note: string }[] = [
  { id: "keep", label: "Keep", note: "Looks like a photo of a person" },
  { id: "review", label: "Review", note: "Unsure — have a look" },
  { id: "junk", label: "Junk", note: "Screenshot noise, not a portrait" },
];

export function PilotView() {
  const d = useDesk();
  const [drag, setDrag] = useState<string | null>(null);
  const [over, setOver] = useState<Pile | null>(null);
  const items = PILOT.map((shot) => ({
    ...shot,
    pile: d.pileOf(shot.score, shot.id) as Pile,
    manual: Boolean(d.overrides[shot.id]),
  }));

  return (
    <div>
      <p className="kicker">Photos pilot</p>
      <h1 style={{ fontSize: "clamp(32px, 4vw, 48px)" }}>Sort the screenshot pile.</h1>
      <p className="lede">
        A read-only pass over the macOS Photos library. It crops the likely photo out of each screenshot, scores whether it looks like a person, and sorts keep, review, or junk. Nothing here is imported.
      </p>

      <div className="panel" style={{ marginTop: 18, padding: 14, borderRadius: 16, border: "1px solid var(--line)" }}>
        <div className="spread">
          <label className="field" style={{ flex: 1 }}>
            <span>Keep at or above {d.keepAt.toFixed(2)}</span>
            <input type="range" min={0.5} max={0.95} step={0.01} value={d.keepAt} onChange={(e) => d.setKeepAt(Number(e.target.value))} />
          </label>
          <label className="field" style={{ flex: 1 }}>
            <span>Junk at or below {d.junkAt.toFixed(2)}</span>
            <input type="range" min={0.05} max={0.6} step={0.01} value={d.junkAt} onChange={(e) => d.setJunkAt(Number(e.target.value))} />
          </label>
          <button type="button" className="btn tiny" disabled={!d.undoStack.length} onClick={d.undoPile}>Undo correction</button>
        </div>
        <div className="hist" aria-hidden>
          {PILOT.map((p) => (
            <i key={p.id} className={d.pileOf(p.score, p.id)} style={{ left: `${p.score * 100}%` }} />
          ))}
          <em style={{ left: `${d.junkAt * 100}%` }} />
          <em style={{ left: `${d.keepAt * 100}%` }} />
        </div>
        <p className="hint">Marks are this sample. Lines are your thresholds. A manual move stays put when the sliders change.</p>
      </div>

      <div className="piles" style={{ marginTop: 14 }}>
        {PILES.map((pile) => {
          const cards = items.filter((item) => item.pile === pile.id);
          return (
            <section
              key={pile.id}
              className={cn("pile", pile.id, over === pile.id && "over")}
              onDragOver={(e) => { e.preventDefault(); setOver(pile.id); }}
              onDragLeave={() => setOver((v) => (v === pile.id ? null : v))}
              onDrop={() => {
                if (drag) d.setPile(drag, pile.id);
                setDrag(null);
                setOver(null);
              }}
            >
              <h3>{pile.label} <span>{cards.length}</span></h3>
              <p className="hint">{pile.note}</p>
              {cards.map((item) => (
                <PilotCard key={item.id} item={item} onDrag={() => setDrag(item.id)} />
              ))}
              {!cards.length && <p className="hint" style={{ marginTop: 16 }}>Nothing in {pile.label.toLowerCase()} at this threshold.</p>}
            </section>
          );
        })}
      </div>
    </div>
  );
}

function PilotCard({ item, onDrag }: { item: PilotShot & { pile: Pile; manual: boolean }; onDrag: () => void }) {
  const d = useDesk();
  return (
    <article className="pilot-card" draggable onDragStart={onDrag}>
      <div className="shot">
        <img src={item.screenshot} alt="" />
        <img src={item.crop} alt={item.file} />
      </div>
      <div className="body">
        <div className="spread">
          <strong style={{ fontFamily: "var(--serif)", fontSize: 22 }}>{item.score.toFixed(2)}</strong>
          <span className="hint">{item.manual ? "Manual" : item.person ? "Person-like" : "Not a person"}</span>
        </div>
        <p className="mono" style={{ color: "var(--dust)" }}>{item.file}</p>
        <div className="row">
          {(["keep", "review", "junk"] as Pile[]).map((pile) => (
            <button key={pile} type="button" className={cn("chip", item.pile === pile && "on")} onClick={() => d.setPile(item.id, pile)}>
              {pile}
            </button>
          ))}
        </div>
      </div>
    </article>
  );
}
