import { useEffect, useMemo, useState, type ReactNode } from "react";
import { ARCHIVE } from "../data";
import { useDesk, type View } from "../store";
import { cn } from "../utils/cn";
import { Slideshow } from "./Frames";
import { Icon, Modal, Seg } from "./ui";

const NAV: { id: View; label: string; icon: string }[] = [
  { id: "search", label: "Search", icon: "search" },
  { id: "library", label: "Library", icon: "grid" },
  { id: "collections", label: "Collections", icon: "folder" },
  { id: "pilot", label: "Pilot", icon: "aperture" },
];

export function Chrome({ children }: { children: ReactNode }) {
  const d = useDesk();
  const running = d.jobs.filter((j: { status: string }) => j.status === "running").length;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      const typing = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        d.setPaletteOpen(true);
        return;
      }
      if (e.key === "/" && !typing) {
        e.preventDefault();
        d.setView("search");
        d.setComposerOpen(true);
        window.setTimeout(() => document.getElementById("query")?.focus(), 30);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [d]);

  return (
    <div className="app">
      <nav className="nav">
        <button type="button" className="brand" onClick={() => d.setView("search")} aria-label="Postroom home">
          <span className="mark" aria-hidden><i /><i /><i /><i /></span>
          <span className="brand-name">Postroom</span>
        </button>
        {NAV.map((item) => (
          <button key={item.id} type="button" className={cn("nav-btn", d.view === item.id && "active")} onClick={() => d.setView(item.id)}>
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </button>
        ))}
        <div className="nav-foot">
          <button type="button" className="nav-key" onClick={() => d.setPaletteOpen(true)} aria-label="Command palette">⌘K</button>
        </div>
      </nav>
      <div className="main">
        <header className="topbar">
          <div className="topbar-inner">
            <p className="crumb">
              {NAV.find((n) => n.id === d.view)?.label}
              <span> · local desk · {ARCHIVE.host}</span>
            </p>
            <div className="top-actions">
              <Seg
                label="Search model"
                value={d.model}
                onChange={d.setModel}
                options={[{ id: "siglip", label: "SigLIP" }, { id: "clip", label: "CLIP" }]}
              />
              <button type="button" className="session-chip" onClick={() => d.setSessionOpen(true)}>
                <i className={cn("dot", d.sessionOk ? "ok" : "bad")} />
                {d.sessionOk ? "@mira.chen" : "No session"}
              </button>
              <button type="button" className="btn tiny" onClick={() => d.setJobsOpen(!d.jobsOpen)}>
                {running > 0 && <i className="dot live" style={{ marginRight: 6 }} />}
                Jobs{running ? ` ${running}` : ""}
              </button>
            </div>
          </div>
        </header>
        <div className="stage">{children}</div>
        <JobsTray />
      </div>
      <div className="toast-wrap" aria-live="polite">
        {d.toasts.map((t: { id: string; text: string }) => <div key={t.id} className="toast">{t.text}</div>)}
      </div>
      <Slideshow />
      {d.refineOpen && <RefineDrawer />}
      {d.sessionOpen && <SessionSheet />}
      {d.prepareFor !== null && <PrepareSheet />}
      {d.importKind && <ImportSheet />}
      {d.paletteOpen && <Palette />}
    </div>
  );
}

function JobsTray() {
  const d = useDesk();
  if (!d.jobs.length && !d.jobsOpen) return null;
  const active = d.jobs.find((j: { id: string }) => j.id === d.activeJob) || d.jobs[0];
  return (
    <div className="tray">
      <div className="tray-inner">
        <div className="spread">
          <div className="row">
            <button type="button" className="btn tiny" onClick={() => d.setJobsOpen(!d.jobsOpen)}>{d.jobsOpen ? "Hide" : "Show"} jobs</button>
            {d.jobs.slice(0, 4).map((j: { id: string; title: string; status: string }) => (
              <button key={j.id} type="button" className={cn("chip", active?.id === j.id && "on")} onClick={() => { d.setActiveJob(j.id); d.setJobsOpen(true); }}>
                {j.status === "running" ? "● " : ""}{j.title}
              </button>
            ))}
          </div>
          {active && (
            <div className="row">
              <span className="mono" style={{ color: "var(--dust)" }}>pid {active.pid}</span>
              {active.status === "running" && <button type="button" className="btn tiny danger" onClick={() => d.stopJob(active.id)}>Stop</button>}
              <button type="button" className="btn tiny" onClick={() => d.dismissJob(active.id)}>Dismiss</button>
            </div>
          )}
        </div>
        {d.jobsOpen && active && (
          <>
            <div className="progress"><i style={{ width: `${active.progress}%` }} /></div>
            <pre>{active.log.join("\n")}</pre>
            <p className="hint">{active.logPath} · {active.status} · {Math.round(active.progress)}%</p>
          </>
        )}
        {d.jobsOpen && !active && <p className="hint">Prepare, index, and imports show up here and keep their log after a refresh.</p>}
      </div>
    </div>
  );
}

function RefineDrawer() {
  const d = useDesk();
  return (
    <div className="drawer-back" onMouseDown={() => d.setRefineOpen(false)}>
      <aside className="drawer" onMouseDown={(e) => e.stopPropagation()} role="dialog" aria-label="Refine search">
        <header>
          <div>
            <p className="kicker">Refine</p>
            <h2>The quieter controls.</h2>
          </div>
          <button type="button" className="icon-btn" aria-label="Close" onClick={() => d.setRefineOpen(false)}><Icon name="x" /></button>
        </header>
        <p className="hint">The main desk stays a query. Dates, cache, carousels, and video live here so they don’t crowd the search.</p>
        <div className="section">
          <p className="lbl">When</p>
          <div className="chips">
            <button type="button" className="chip" onClick={() => { d.setDateFrom(""); d.setDateTo(""); }}>Any</button>
            <button type="button" className="chip" onClick={() => {
              const to = new Date();
              const from = new Date();
              from.setDate(from.getDate() - 90);
              d.setDateFrom(from.toISOString().slice(0, 10));
              d.setDateTo(to.toISOString().slice(0, 10));
            }}>90 days</button>
            <button type="button" className="chip" onClick={() => { d.setDateFrom("2025-01-01"); d.setDateTo("2025-12-31"); }}>2025</button>
            <button type="button" className="chip" onClick={() => { d.setDateFrom("2024-01-01"); d.setDateTo("2024-12-31"); }}>2024</button>
          </div>
          <div className="two">
            <label className="field"><span>From</span><input type="date" value={d.dateFrom} onChange={(e) => d.setDateFrom(e.target.value)} /></label>
            <label className="field"><span>To</span><input type="date" value={d.dateTo} onChange={(e) => d.setDateTo(e.target.value)} /></label>
          </div>
          <p className="hint">Dates come from Instagram post codes. Imported files have none, so a date filter hides them.</p>
        </div>
        <div className="section">
          <p className="lbl">Media</p>
          <button type="button" className={cn("toggle", d.includeVideo && "on")} onClick={() => d.setIncludeVideo(!d.includeVideo)}>
            <span className="track"><span className="knob" /></span>
            <span><strong>Include reels and videos</strong><small>Off by default, so a photo search stays a photo search.</small></span>
          </button>
          <label className="field">
            <span>Imported clip length · {d.clipLength.toFixed(1)}s</span>
            <input type="range" min={1} max={12} step={0.5} value={d.clipLength} onChange={(e) => d.setClipLength(Number(e.target.value))} />
          </label>
          <Seg
            label="Carousels"
            value={d.carouselMode}
            onChange={d.setCarouselMode}
            options={[{ id: "cover", label: "Cover" }, { id: "all", label: "Every slide" }, { id: "index", label: "Index later" }]}
          />
          <p className="hint">Cover uses the saved frame. Every slide expands the result. Index later marks promising carousels for the library job.</p>
        </div>
        <div className="section">
          <p className="lbl">Cache</p>
          <Seg
            label="Cache"
            value={d.cacheMode}
            onChange={d.setCacheMode}
            options={[{ id: "cache", label: "Saved" }, { id: "refresh", label: "Check new" }, { id: "rebuild", label: "Rebuild" }]}
          />
          <p className="hint">Rebuild ignores the cache and reads the profile again. First run on a new model can take several minutes.</p>
          <label className="field">
            <span>Cap when taking all · {d.cap}</span>
            <input type="range" min={12} max={80} step={4} value={d.cap} onChange={(e) => d.setCap(Number(e.target.value))} />
          </label>
        </div>
        <button type="button" className="btn primary" onClick={() => { d.setRefineOpen(false); d.find(); }}>Find with these</button>
      </aside>
    </div>
  );
}

function SessionSheet() {
  const d = useDesk();
  const [stage, setStage] = useState<"idle" | "browser" | "saved">("idle");
  return (
    <Modal kicker="This desk" title="Session, indexes, storage" onClose={() => d.setSessionOpen(false)}>
      <div className="section" style={{ borderTop: 0, paddingTop: 0 }}>
        <div className="spread">
          <div>
            <p className="kicker">auth.json</p>
            <h3>{d.sessionOk ? "Session looks valid" : "Session expired"}</h3>
            <p className="hint">{d.sessionOk ? "@mira.chen" : "Searches that scrape Instagram will stop."} · checked {d.sessionChecked}</p>
          </div>
          <i className={cn("dot", d.sessionOk ? "ok" : "bad")} />
        </div>
        <div className="row">
          <button type="button" className="btn tiny" onClick={d.checkSession} disabled={d.checking}>{d.checking ? "Checking…" : "Check session"}</button>
          <button type="button" className="btn tiny" onClick={() => d.setSessionOk(false)}>Forget session</button>
        </div>
        {stage === "idle" && (
          <button type="button" className="btn primary" onClick={() => setStage("browser")}>Open login browser</button>
        )}
        {stage === "browser" && (
          <div className="panel" style={{ padding: 12, borderRadius: 12, border: "1px solid var(--line)" }}>
            <p className="mono">Playwright · instagram.com</p>
            <p className="hint">A visible browser opens on this Mac. Sign in there, including 2FA. Postroom never asks for the password here.</p>
            <button type="button" className="btn tiny" onClick={() => { setStage("saved"); d.setSessionOk(true); d.toast("Saved storage state to auth.json"); }}>I’ve signed in</button>
          </div>
        )}
        {stage === "saved" && <p className="hint sage">Storage state saved to auth.json. Treat that file as a logged-in browser.</p>}
      </div>
      <div className="section">
        <p className="lbl">Index</p>
        <p className="hint">SigLIP is the current embedding index. CLIP is the older one. Each account keeps them apart. Switching does not delete either.</p>
      </div>
      <div className="section">
        <p className="lbl">On disk</p>
        {[
          ["cache/", `${ARCHIVE.cache} · posts, thumbs, indexes, job logs`],
          ["picks/", "Saved search results"],
          ["favourites/", "Starred copies and favourites.json"],
          ["library/", `${ARCHIVE.library} · categorized folders`],
          ["pilot/", "Screenshot crops and scores"],
          ["auth.json", "Playwright storage state"],
        ].map(([path, note]) => (
          <button key={path} type="button" className="count-line" onClick={() => d.copyText(path)}>
            <span>{path}</span>
            <em>{note}</em>
          </button>
        ))}
      </div>
      <div className="section">
        <p className="hint">This desk runs the same controls as the local app. Search, jobs, and imports here use the working set in the browser.</p>
        <button type="button" className="btn tiny danger" onClick={d.resetDesk}>Reset preview data</button>
      </div>
    </Modal>
  );
}

function PrepareSheet() {
  const d = useDesk();
  const [handle, setHandle] = useState(d.prepareFor || "");
  const [n, setN] = useState(12);
  return (
    <Modal kicker="Prepare" title="Build the index first." onClose={() => d.setPrepareFor(null)}>
      <p className="hint">Prepare fills thumbnails, the photo index, pose, post types, tag counts, and library folders. It can also index a number of carousels up front so later searches don’t wait.</p>
      <label className="field" style={{ marginTop: 12 }}>
        <span>Account</span>
        <input className="textin" value={handle} onChange={(e) => setHandle(e.target.value)} placeholder="luna.atelier" />
      </label>
      <div className="chips" style={{ marginTop: 8 }}>
        {d.accounts.map((a: { handle: string }) => (
          <button type="button" key={a.handle} className={cn("chip", handle === a.handle && "on")} onClick={() => setHandle(a.handle)}>@{a.handle}</button>
        ))}
      </div>
      <label className="field" style={{ marginTop: 12 }}>
        <span>Carousel posts to index now · {n}</span>
        <input type="range" min={0} max={40} step={1} value={n} onChange={(e) => setN(Number(e.target.value))} />
      </label>
      <p className="hint">The rest can continue later from Library, in batches, with one to three workers.</p>
      <button type="button" className="btn primary" style={{ marginTop: 14 }} onClick={() => d.startPrepare(handle, n)}>Start prepare</button>
    </Modal>
  );
}

function ImportSheet() {
  const d = useDesk();
  const kind = d.importKind as "images" | "videos";
  const [name, setName] = useState("");
  const [path, setPath] = useState("");
  const [pending, setPending] = useState(kind === "videos" ? 3 : 12);
  return (
    <Modal kicker="Import" title={kind === "videos" ? "Video folder or file" : "Folder of images"} onClose={() => d.setImportKind(null)}>
      <p className="hint">
        {kind === "videos"
          ? "Videos are stored as sampled frames. The clip itself is cut when you play or save, at the length set in Refine."
          : "Postroom keeps the original path and a resized searchable copy. The collection becomes an account you can search."}
      </p>
      <label className="field" style={{ marginTop: 12 }}>
        <span>Name</span>
        <input className="textin" value={name} onChange={(e) => setName(e.target.value)} placeholder={kind === "videos" ? "Trip clips" : "Reference pulls"} />
      </label>
      <label className="field">
        <span>Path</span>
        <input className="textin" value={path} onChange={(e) => setPath(e.target.value)} placeholder={kind === "videos" ? "/Users/mira/Movies/trip" : "/Users/mira/Pictures/pulls"} />
      </label>
      <label className="btn tiny" style={{ marginTop: 8, display: "inline-block" }}>
        Browse
        <input
          type="file"
          multiple
          accept={kind === "videos" ? "video/*" : "image/*"}
          hidden
          onChange={(e) => {
            const files = [...(e.target.files || [])];
            if (!files.length) return;
            const folder = files[0].webkitRelativePath?.split("/")[0] || files[0].name;
            setPath((p: string) => p || `/Users/mira/imports/${folder}`);
            setName((n: string) => n || folder.replace(/\.[^.]+$/, ""));
            setPending(files.length);
          }}
        />
      </label>
      <label className="field" style={{ marginTop: 10 }}>
        <span>Files to index · {pending}</span>
        <input type="range" min={1} max={40} value={pending} onChange={(e) => setPending(Number(e.target.value))} />
      </label>
      <button
        type="button"
        className="btn primary"
        style={{ marginTop: 14 }}
        onClick={() => {
          if (!name.trim() || !path.trim()) {
            d.toast("Name and path are both needed.");
            return;
          }
          d.addSource({ name: name.trim(), path: path.trim(), kind, pending });
        }}
      >
        Start import
      </button>
    </Modal>
  );
}

function Palette() {
  const d = useDesk();
  const [q, setQ] = useState("");
  const [cursor, setCursor] = useState(0);
  const commands = useMemo(() => [
    { id: "search", label: "Go to search", hint: "Desk", run: () => d.setView("search") },
    { id: "library", label: "Go to library", hint: "Tags and counts", run: () => d.setView("library") },
    { id: "imports", label: "Open imports", hint: "Folders and video", run: () => { d.setView("collections"); d.setCollectionsTab("imports"); } },
    { id: "favs", label: "Open favourites", hint: "Starred frames", run: () => { d.setView("collections"); d.setCollectionsTab("favourites"); } },
    { id: "pilot", label: "Open photos pilot", hint: "Keep, review, junk", run: () => d.setView("pilot") },
    { id: "prepare", label: "Prepare an account", hint: "Indexes up front", run: () => d.setPrepareFor("") },
    { id: "refine", label: "Open refine", hint: "Dates, cache, video", run: () => { d.setView("search"); d.setRefineOpen(true); } },
    { id: "model", label: d.model === "siglip" ? "Switch to CLIP" : "Switch to SigLIP", hint: "Separate indexes", run: () => d.setModel(d.model === "siglip" ? "clip" : "siglip") },
    { id: "session", label: "Session and login", hint: "auth.json", run: () => d.setSessionOpen(true) },
    { id: "jobs", label: "Show jobs", hint: "Logs and stop", run: () => d.setJobsOpen(true) },
    { id: "random", label: "Draw random posts", hint: "Ignore the query once", run: () => d.find({ forceRandom: true }) },
  ], [d]);
  const filtered = commands.filter((c) => c.label.toLowerCase().includes(q.toLowerCase()));
  const current = filtered[Math.min(cursor, Math.max(0, filtered.length - 1))];

  return (
    <div className="modal-back" onMouseDown={() => d.setPaletteOpen(false)}>
      <div className="palette" role="dialog" aria-label="Commands" onMouseDown={(e) => e.stopPropagation()}>
        <input
          autoFocus
          value={q}
          placeholder="Jump, prepare, switch index…"
          onChange={(e) => { setQ(e.target.value); setCursor(0); }}
          onKeyDown={(e) => {
            if (e.key === "Escape") d.setPaletteOpen(false);
            if (e.key === "ArrowDown") { e.preventDefault(); setCursor((c) => Math.min(filtered.length - 1, c + 1)); }
            if (e.key === "ArrowUp") { e.preventDefault(); setCursor((c) => Math.max(0, c - 1)); }
            if (e.key === "Enter" && current) { current.run(); d.setPaletteOpen(false); }
          }}
        />
        {filtered.map((c, i) => (
          <button key={c.id} type="button" className={cn("cmd", i === cursor && "on")} onMouseEnter={() => setCursor(i)} onClick={() => { c.run(); d.setPaletteOpen(false); }}>
            {c.label}
            <small>{c.hint}</small>
          </button>
        ))}
        {!filtered.length && <p className="hint" style={{ padding: 16 }}>No command.</p>}
      </div>
    </div>
  );
}
