import { formatDate } from "../data";
import type { Scored } from "../search";
import { useDesk } from "../store";
import { cn } from "../utils/cn";
import { ContactSheet } from "./Frames";
import { Icon, Star } from "./ui";

export function CollectionsView() {
  const d = useDesk();
  const pending = d.sources.reduce((sum: number, s: { pending: number }) => sum + s.pending, 0);
  const favAccounts = [...new Set(d.favs.map((f: { account: string }) => f.account))] as string[];
  const shownFavs = d.favs.filter((f: { account: string }) => d.favFilter === "all" || f.account === d.favFilter);
  const favFrames: Scored[] = shownFavs.map((f: { id: string; account: string; src: string; code: string | null; caption: string; filename: string }) => {
    const base = d.frames.find((frame: { id: string }) => frame.id === f.id.split(":")[0]);
    return {
      ...(base || {
        id: f.id,
        account: f.account,
        src: f.src,
        date: null,
        code: f.code,
        kind: "photo" as const,
        slides: [f.src],
        tags: { setting: "none", outfit: "none", shot: "none", pose: "none", arms: "none" },
        conf: { setting: 0, outfit: 0, shot: 0 },
        caption: f.caption,
        local: false,
        sig: 1,
        clip: 1,
        focus: "50% 30%",
      }),
      src: f.src,
      score: base?.sig || 0.8,
      slideIndex: 0,
      resultId: f.id,
    };
  });

  return (
    <div>
      <p className="kicker">Collections</p>
      <div className="spread">
        <h1 style={{ fontSize: "clamp(32px, 4vw, 48px)" }}>Imports and favourites.</h1>
        <div className="seg" role="tablist" aria-label="Collection">
          <button type="button" className={d.collectionsTab === "imports" ? "on" : ""} onClick={() => d.setCollectionsTab("imports")}>Imports {pending ? `· ${pending}` : ""}</button>
          <button type="button" className={d.collectionsTab === "favourites" ? "on" : ""} onClick={() => d.setCollectionsTab("favourites")}>Favourites · {d.favs.length}</button>
        </div>
      </div>

      {d.collectionsTab === "imports" ? (
        <div className="stack" style={{ marginTop: 18 }}>
          <div className="panel" style={{ padding: 14, borderRadius: 16, border: "1px solid var(--line)" }}>
            <button type="button" className={cn("toggle", d.autoImport && "on")} onClick={() => d.setAutoImport(!d.autoImport)}>
              <span className="track"><span className="knob" /></span>
              <span>
                <strong>Check for pending files when Postroom opens</strong>
                <small>It only reports them. Import stays a deliberate click.</small>
              </span>
            </button>
          </div>
          <div className="row">
            <button type="button" className="btn primary" onClick={() => d.setImportKind("images")}>Import image folder</button>
            <button type="button" className="btn" onClick={() => d.setImportKind("videos")}>Import video</button>
            <button type="button" className="btn" onClick={d.startImportAll} disabled={!pending}>Import all pending</button>
          </div>
          {d.sources.map((s: { id: string; name: string; path: string; kind: string; indexed: number; pending: number; added: string; feeds?: string }) => (
            <article key={s.id} className="source">
              <div>
                <p className="kicker">{s.kind === "videos" ? "Video" : "Images"}</p>
                <h3>{s.name}</h3>
                <p className="mono" style={{ color: "var(--dust)", margin: "4px 0" }}>{s.path}</p>
                <p className="hint">
                  {s.indexed} indexed · added {formatDate(s.added)}
                  {s.feeds ? ` · feeds @${s.feeds}` : " · own collection"}
                </p>
              </div>
              <div className="stack" style={{ justifyItems: "end" }}>
                <span className="pending">{s.pending ? `${s.pending} pending` : "Up to date"}</span>
                <div className="row">
                  <button type="button" className="btn tiny" disabled={!s.pending} onClick={() => d.startImport(s.id)}>Import new</button>
                  <button type="button" className="btn tiny" onClick={() => d.reveal(s.path)}>Finder</button>
                  {s.kind === "videos" && (
                    <button
                      type="button"
                      className="btn tiny"
                      onClick={() => {
                        const clip = d.frames.find((f: { account: string; video?: string }) => f.video && (f.account === s.feeds || f.account === "desk.imports"));
                        if (clip) d.openSlides([{ ...clip, score: clip.sig, slideIndex: 0, resultId: clip.id }], 0);
                        else d.toast("No sampled clip in the working set yet.");
                      }}
                    >
                      <Icon name="play" size={14} /> Play
                    </button>
                  )}
                </div>
              </div>
            </article>
          ))}
          <p className="hint">Local files have no Instagram date. A date filter on Search hides them. Videos are stored as sampled frames; the clip is cut when you play or save.</p>
        </div>
      ) : (
        <div style={{ marginTop: 18 }}>
          <div className="spread" style={{ marginBottom: 12 }}>
            <div className="chips">
              <button type="button" className={cn("chip", d.favFilter === "all" && "on")} onClick={() => d.setFavFilter("all")}>All</button>
              {favAccounts.map((a) => (
                <button type="button" key={a} className={cn("chip", d.favFilter === a && "on")} onClick={() => d.setFavFilter(a)}>@{a}</button>
              ))}
            </div>
            <div className="row">
              <button type="button" className="btn tiny" onClick={() => d.reveal("favourites")}>Open folder</button>
              <button type="button" className="btn tiny" onClick={() => d.toast(`Saved ${shownFavs.length} favourites to picks/`)} disabled={!shownFavs.length}>Download</button>
            </div>
          </div>
          {favFrames.length ? (
            <ContactSheet items={favFrames} />
          ) : (
            <div className="empty">
              <h2>No favourites yet.</h2>
              <p className="hint">The star on a frame copies it into favourites/&lt;account&gt;/ and records the link.</p>
            </div>
          )}
          {!!shownFavs.length && (
            <div className="list" style={{ marginTop: 14 }}>
              {shownFavs.map((f: { id: string; account: string; filename: string; savedAt: string; code: string | null; caption: string }) => (
                <div key={f.id} className="list-row" style={{ gridTemplateColumns: "1fr auto" }}>
                  <div>
                    <h3>@{f.account} · {f.filename}</h3>
                    <p>{f.caption} · {new Date(f.savedAt).toLocaleString()}</p>
                  </div>
                  <button type="button" className="btn tiny" onClick={() => d.toggleFav(f)}>
                    <Star filled /> Unfavourite
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
