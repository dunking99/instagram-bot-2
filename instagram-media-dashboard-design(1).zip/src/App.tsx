import { Chrome } from "./components/Chrome";
import { CollectionsView } from "./components/CollectionsView";
import { LibraryView } from "./components/LibraryView";
import { PilotView } from "./components/PilotView";
import { SearchView } from "./components/SearchView";
import { DeskProvider, useDesk } from "./store";

function Shell() {
  const { view } = useDesk();
  return (
    <Chrome>
      {view === "search" && <SearchView />}
      {view === "library" && <LibraryView />}
      {view === "collections" && <CollectionsView />}
      {view === "pilot" && <PilotView />}
    </Chrome>
  );
}

export default function App() {
  return (
    <DeskProvider>
      <Shell />
    </DeskProvider>
  );
}
