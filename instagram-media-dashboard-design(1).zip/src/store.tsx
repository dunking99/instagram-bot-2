import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import {
  INITIAL_ACCOUNTS,
  INITIAL_FRAMES,
  INITIAL_SOURCES,
  stubAccount,
  type Account,
  type Fav,
  type Frame,
  type Job,
  type Source,
  type TagGroup,
} from "./data";
import {
  buildLog,
  computeSearch,
  type CacheMode,
  type CarouselMode,
  type Mix,
  type Polarity,
  type ResultMode,
  type Scored,
  type SearchParams,
  type TagPick,
} from "./search";

const KEY = "postroom.v1";
export type View = "search" | "library" | "collections" | "pilot";
export type Pile = "keep" | "review" | "junk";
export type Toast = { id: string; text: string };

export type RunMeta = {
  mode: "random" | "ranked";
  polarity: Polarity;
  excludedLocal: number;
  skippedModel: string[];
  skippedPose: string[];
  pool: number;
  resultMode: ResultMode;
  carouselMode: CarouselMode;
};

type SlideState = { open: boolean; items: Scored[]; index: number };
type Undo = { id: string; prev: Pile | null };

type Saved = {
  model?: "siglip" | "clip";
  selectedAccounts?: string[];
  autoImport?: boolean;
  favs?: Fav[];
  overrides?: Record<string, Pile>;
  undoStack?: Undo[];
  keepAt?: number;
  junkAt?: number;
  jobs?: Job[];
  accounts?: Account[];
  sources?: Source[];
  frames?: Frame[];
  sessionOk?: boolean;
};

function loadSaved(): Saved | null {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Saved) : null;
  } catch {
    return null;
  }
}

const saved = loadSaved();

function mergeAccounts(list?: Account[]) {
  if (!list?.length) return INITIAL_ACCOUNTS;
  const base = INITIAL_ACCOUNTS.map((a) => {
    const s = list.find((x) => x.handle === a.handle);
    return s ? { ...a, ...s, cover: a.cover } : a;
  });
  return [...base, ...list.filter((s) => !INITIAL_ACCOUNTS.some((a) => a.handle === s.handle))];
}

function mergeFrames(list?: Frame[]) {
  if (!list?.length) return INITIAL_FRAMES;
  return [...INITIAL_FRAMES, ...list.filter((f) => !INITIAL_FRAMES.some((i) => i.id === f.id))];
}

function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 7)}`;
}

function scriptFor(job: Job) {
  const acct = job.account ? `@${job.account}` : "collection";
  if (job.kind === "prepare") {
    return [
      `random_post.py --prepare ${job.account}`,
      "session · auth.json",
      `posts · cache/posts/${job.account}.json`,
      "thumbnails · filling gaps",
      `embedding · ${job.model || "siglip"} index`,
      "pose keypoints",
      "tags · setting, outfit, shot",
      job.carouselCount ? `carousels · indexing ${job.carouselCount}` : "carousels · covers only",
      `library/${job.account} · folders`,
      `done · ${acct}`,
    ];
  }
  if (job.kind === "index") {
    return [
      `carousel expansion · ${acct}`,
      (job.workers || 1) > 1
        ? `warning · ${job.workers} workers increase Instagram page loads`
        : "workers · 1 · gentler on the session",
      job.untilDone ? "run until remaining slides are indexed" : `batch · ${job.batch || 25} posts`,
      "opening carousels",
      "writing slide embeddings",
      "thumbnails · slides",
      "done",
    ];
  }
  if (job.kind === "pose") {
    return [`pose index · ${acct}`, "reading saved thumbnails", "keypoints · standing, walking, seated, leaning", "arms classes", "done"];
  }
  if (job.kind === "detect") {
    return [`detect carousels · ${acct}`, "reading post types from cache", "marking multi-photo posts", "done · slide totals updated"];
  }
  if (job.kind === "library") {
    return [`rebuild library/${job.account}`, "grouping setting, outfit, shot, pose, arms", "writing manifest", "done"];
  }
  return [
    `import · ${job.sourceName || job.title}`,
    job.path || "reading folder",
    "resized searchable copies",
    job.sourceKind === "videos" ? "sampling frames · clips cut on demand" : "embedding images",
    "updating source map",
    "done",
  ];
}

function reduceAccounts(accounts: Account[], job: Job): Account[] {
  if (job.kind === "import") {
    if (!job.createCollection || !job.account) return accounts;
    if (accounts.some((a) => a.handle === job.account)) return accounts;
    const n = job.pendingCount || 8;
    return [
      ...accounts,
      {
        ...stubAccount(job.account),
        kind: "local",
        photos: job.sourceKind === "videos" ? 0 : n,
        reels: job.sourceKind === "videos" ? n : 0,
        pose: true,
        carouselDetected: true,
        models: { siglip: true, clip: true },
        prepared: new Date().toISOString().slice(0, 10),
        libraryBuilt: false,
        cover: INITIAL_FRAMES[0]?.src || stubAccount(job.account).cover,
      },
    ];
  }
  if (!job.account) return accounts;
  return accounts.map((a) => {
    if (a.handle !== job.account) return a;
    if (job.kind === "prepare") {
      const fresh = a.photos === 0;
      const slides = job.carouselCount || 0;
      return {
        ...a,
        photos: fresh ? 120 : a.photos,
        reels: fresh ? 8 : a.reels,
        carousels: fresh ? Math.max(slides, 10) : a.carousels,
        slidesTotal: fresh ? Math.max(slides, 10) : Math.max(a.slidesTotal, slides),
        slidesIndexed: Math.max(a.slidesIndexed, slides),
        pose: true,
        carouselDetected: true,
        models: { ...a.models, [job.model || "siglip"]: true },
        prepared: new Date().toISOString().slice(0, 10),
        libraryBuilt: true,
      };
    }
    if (job.kind === "index") {
      const next = job.untilDone ? a.slidesTotal : Math.min(a.slidesTotal, a.slidesIndexed + (job.batch || 25));
      return { ...a, slidesIndexed: next, carouselDetected: true };
    }
    if (job.kind === "detect") return { ...a, carouselDetected: true, slidesTotal: a.slidesTotal || 15 };
    if (job.kind === "pose") return { ...a, pose: true };
    if (job.kind === "library") return { ...a, libraryBuilt: true };
    return a;
  });
}

function reduceSources(sources: Source[], job: Job): Source[] {
  if (job.kind !== "import" || !job.sourceId) return sources;
  return sources.map((s) => (s.id === job.sourceId ? { ...s, indexed: s.indexed + s.pending, pending: 0 } : s));
}

function addFrames(frames: Frame[], job: Job): Frame[] {
  if (job.kind !== "import" || !job.createCollection || !job.account) return frames;
  if (frames.some((f) => f.account === job.account)) return frames;
  const bases = job.sourceKind === "videos" ? ["f-localv"] : ["f-local1", "f-local2", "f-local3"];
  const clones: Frame[] = [];
  bases.forEach((id, n) => {
    const base = INITIAL_FRAMES.find((f) => f.id === id);
    if (!base || !job.account) return;
    const file = base.path?.split("/").pop() || `frame-${n}.jpg`;
    clones.push({
      ...base,
      id: `${job.account}-${id}`,
      account: job.account,
      local: true,
      date: null,
      code: null,
      path: `${job.path || "/Users/mira/imports"}/${file}`,
    });
  });
  return [...frames, ...clones];
}

type FindPatch = {
  text?: string;
  selected?: string[];
  useText?: boolean;
  useImage?: boolean;
  usePose?: boolean;
  tags?: TagPick[];
  dateFrom?: string;
  dateTo?: string;
  includeVideo?: boolean;
  forceRandom?: boolean;
};

type Live = {
  frames: Frame[];
  accounts: Account[];
  selectedAccounts: string[];
  model: "siglip" | "clip";
  text: string;
  useText: boolean;
  useImage: boolean;
  refImage: string | null;
  imageWeight: number;
  usePose: boolean;
  poseImage: string | null;
  mirrorPose: boolean;
  tags: TagPick[];
  confidence: number;
  polarity: Polarity;
  count: number;
  takeAll: boolean;
  cap: number;
  mix: Mix;
  dateFrom: string;
  dateTo: string;
  includeVideo: boolean;
  carouselMode: CarouselMode;
  cacheMode: CacheMode;
  clipLength: number;
  resultMode: ResultMode;
  sessionOk: boolean;
};

const DeskContext = createContext<any>(null);

export function useDesk() {
  const ctx = useContext(DeskContext);
  if (!ctx) throw new Error("Desk missing");
  return ctx;
}

export function DeskProvider({ children }: { children: ReactNode }) {
  const [view, setView] = useState<View>("search");
  const [model, setModelState] = useState<"siglip" | "clip">(saved?.model || "siglip");
  const [sessionOk, setSessionOk] = useState(saved?.sessionOk ?? true);
  const [sessionChecked, setSessionChecked] = useState("cached");
  const [checking, setChecking] = useState(false);
  const [accounts, setAccounts] = useState<Account[]>(() => mergeAccounts(saved?.accounts));
  const [frames, setFrames] = useState<Frame[]>(() => mergeFrames(saved?.frames));
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>(
    saved?.selectedAccounts?.length ? saved.selectedAccounts : ["luna.atelier", "northroom"],
  );
  const [sources, setSources] = useState<Source[]>(saved?.sources?.length ? saved.sources : INITIAL_SOURCES);
  const [autoImport, setAutoImport] = useState(saved?.autoImport ?? true);
  const [favs, setFavs] = useState<Fav[]>(saved?.favs || [
    {
      id: "f-blazer",
      account: "luna.atelier",
      src: INITIAL_FRAMES.find((f) => f.id === "f-blazer")?.src || "",
      code: INITIAL_FRAMES.find((f) => f.id === "f-blazer")?.code || null,
      savedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      filename: "blazer.jpg",
      caption: "tailored blazer on a quiet street",
    },
  ]);
  const [jobs, setJobs] = useState<Job[]>(saved?.jobs || []);
  const [jobsOpen, setJobsOpen] = useState(false);
  const [activeJob, setActiveJob] = useState<string | null>(saved?.jobs?.[0]?.id || null);
  const [text, setText] = useState("");
  const [useText, setUseText] = useState(true);
  const [useImage, setUseImage] = useState(false);
  const [usePose, setUsePose] = useState(false);
  const [refImage, setRefImage] = useState<string | null>(null);
  const [poseImage, setPoseImage] = useState<string | null>(null);
  const [imageWeight, setImageWeight] = useState(0.5);
  const [mirrorPose, setMirrorPose] = useState(false);
  const [tags, setTags] = useState<TagPick[]>([]);
  const [confidence, setConfidence] = useState(0.5);
  const [polarity, setPolarity] = useState<Polarity>("best");
  const [count, setCount] = useState(12);
  const [takeAll, setTakeAll] = useState(false);
  const [cap, setCap] = useState(60);
  const [mix, setMix] = useState<Mix>("pool");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [carouselMode, setCarouselMode] = useState<CarouselMode>("cover");
  const [includeVideo, setIncludeVideo] = useState(false);
  const [clipLength, setClipLength] = useState(4);
  const [cacheMode, setCacheMode] = useState<CacheMode>("cache");
  const [resultMode, setResultMode] = useState<ResultMode>("thumbs");
  const [searching, setSearching] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [showLog, setShowLog] = useState(false);
  const [results, setResults] = useState<Scored[] | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [savedFull, setSavedFull] = useState<string[]>([]);
  const [runMeta, setRunMeta] = useState<RunMeta | null>(null);
  const [lastSummary, setLastSummary] = useState("");
  const [composerOpen, setComposerOpen] = useState(true);
  const [slides, setSlides] = useState<SlideState>({ open: false, items: [], index: 0 });
  const [libraryAccount, setLibraryAccount] = useState("luna.atelier");
  const [picked, setPicked] = useState<TagPick[]>([]);
  const [pendingTag, setPendingTag] = useState<TagPick | null>(null);
  const [galleryLimit, setGalleryLimit] = useState(8);
  const [collectionsTab, setCollectionsTab] = useState<"imports" | "favourites">("imports");
  const [favFilter, setFavFilter] = useState("all");
  const [keepAt, setKeepAtState] = useState(saved?.keepAt ?? 0.72);
  const [junkAt, setJunkAtState] = useState(saved?.junkAt ?? 0.38);
  const [overrides, setOverrides] = useState<Record<string, Pile>>(saved?.overrides || {});
  const [undoStack, setUndoStack] = useState<Undo[]>(saved?.undoStack || []);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [refineOpen, setRefineOpen] = useState(false);
  const [sessionOpen, setSessionOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [prepareFor, setPrepareFor] = useState<string | null>(null);
  const [importKind, setImportKind] = useState<null | "images" | "videos">(null);

  const toast = useCallback((text: string) => {
    const id = uid("t");
    setToasts((prev) => [...prev.slice(-3), { id, text }]);
    window.setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 3200);
  }, []);

  const live = useRef<Live>(null as unknown as Live);
  live.current = {
    frames, accounts, selectedAccounts, model, text, useText, useImage, refImage, imageWeight,
    usePose, poseImage, mirrorPose, tags, confidence, polarity, count, takeAll, cap, mix,
    dateFrom, dateTo, includeVideo, carouselMode, cacheMode, clipLength, resultMode, sessionOk,
  };
  const searchTimer = useRef<number | null>(null);
  const appliedIds = useRef(new Set<string>((saved?.jobs || []).filter((j) => j.applied).map((j) => j.id)));
  const booted = useRef(false);

  useEffect(() => {
    const t = window.setInterval(() => {
      setJobs((prev) =>
        prev.map((job) => {
          if (job.status !== "running") return job;
          const progress = Math.min(100, job.progress + job.step);
          const script = scriptFor(job);
          const want = Math.max(1, Math.ceil((progress / 100) * script.length));
          const log = script.slice(0, want);
          if (progress >= 100) return { ...job, progress: 100, status: "done", log: [...script, `exit 0 · ${job.logPath}`] };
          return { ...job, progress, log };
        }),
      );
    }, 900);
    return () => window.clearInterval(t);
  }, []);

  useEffect(() => {
    const done = jobs.filter((j) => j.status === "done" && !j.applied && !appliedIds.current.has(j.id));
    if (!done.length) return;
    for (const job of done) {
      appliedIds.current.add(job.id);
      setAccounts((prev) => reduceAccounts(prev, job));
      setSources((prev) => reduceSources(prev, job));
      setFrames((prev) => addFrames(prev, job));
      if (job.createCollection && job.account) {
        setSelectedAccounts((prev) => (prev.includes(job.account as string) ? prev : [...prev, job.account as string]));
      }
      toast(`${job.title} finished`);
    }
    setJobs((prev) => prev.map((j) => (appliedIds.current.has(j.id) ? { ...j, applied: true } : j)));
  }, [jobs, toast]);

  useEffect(() => {
    if (booted.current) return;
    booted.current = true;
    if (!autoImport) return;
    const n = sources.reduce((sum, s) => sum + s.pending, 0);
    if (n) toast(`${n} pending files in registered folders`);
  }, [autoImport, sources, toast]);

  useEffect(() => {
    const payload: Saved = {
      model, selectedAccounts, autoImport, favs, overrides, undoStack, keepAt, junkAt,
      jobs, accounts, sources, frames, sessionOk,
    };
    try {
      localStorage.setItem(KEY, JSON.stringify(payload));
    } catch {
      /* preview storage can fill; the desk still runs */
    }
  }, [model, selectedAccounts, autoImport, favs, overrides, undoStack, keepAt, junkAt, jobs, accounts, sources, frames, sessionOk]);

  useEffect(() => () => {
    if (searchTimer.current) window.clearInterval(searchTimer.current);
  }, []);

  const setModel = (next: "siglip" | "clip") => {
    setModelState(next);
    toast(next === "siglip" ? "Using the SigLIP index" : "Using the older CLIP index");
  };

  const find = useCallback((patch?: FindPatch) => {
    const s = { ...live.current, ...patch };
    if (!s.selectedAccounts.length) {
      toast("Add at least one account.");
      return;
    }
    if (!patch?.forceRandom && s.useImage && !s.refImage) {
      toast("Add a reference image, or turn Reference off.");
      return;
    }
    if (!patch?.forceRandom && s.usePose && !s.poseImage) {
      toast("Add a pose reference, or turn Pose off.");
      return;
    }
    const missing = s.selectedAccounts.filter((h) => !s.accounts.find((a) => a.handle === h)?.models[s.model]);
    const allMissing = missing.length === s.selectedAccounts.length;
    if (!s.sessionOk && (s.cacheMode !== "cache" || allMissing)) {
      toast("That needs a saved Instagram session.");
      setSessionOpen(true);
      return;
    }
    if (patch?.text != null) setText(patch.text);
    if (patch?.selected) setSelectedAccounts(patch.selected);
    if (patch?.useText != null) setUseText(patch.useText);
    if (patch?.useImage != null) setUseImage(patch.useImage);
    if (patch?.usePose != null) setUsePose(patch.usePose);
    if (patch?.tags) setTags(patch.tags);
    if (patch?.dateFrom != null) setDateFrom(patch.dateFrom);
    if (patch?.dateTo != null) setDateTo(patch.dateTo);
    if (patch?.includeVideo != null) setIncludeVideo(patch.includeVideo);

    const params: SearchParams = {
      frames: s.frames,
      accounts: s.accounts,
      selected: s.selectedAccounts,
      model: s.model,
      text: s.text,
      useText: s.useText,
      useImage: s.useImage,
      refImage: s.refImage,
      imageWeight: s.imageWeight,
      usePose: s.usePose,
      poseImage: s.poseImage,
      mirrorPose: s.mirrorPose,
      tags: s.tags,
      confidence: s.confidence,
      polarity: s.polarity,
      count: s.count,
      takeAll: s.takeAll,
      cap: s.cap,
      mix: s.mix,
      dateFrom: s.dateFrom,
      dateTo: s.dateTo,
      includeVideo: s.includeVideo,
      carouselMode: s.carouselMode,
      cacheMode: s.cacheMode,
      clipLength: s.clipLength,
      resultMode: s.resultMode,
      seed: Date.now() % 100000,
      forceRandom: patch?.forceRandom,
    };
    const output = computeSearch(params);
    const lines = buildLog(params, output);
    const head = lines.slice(0, -1);
    const tail = lines[lines.length - 1];
    if (searchTimer.current) window.clearInterval(searchTimer.current);
    setSearching(true);
    setShowLog(true);
    setComposerOpen(false);
    setView("search");
    setLogs(head.slice(0, 1));
    let i = 1;
    const delay = s.cacheMode === "rebuild" ? 420 : 220;
    searchTimer.current = window.setInterval(() => {
      if (i < head.length) {
        i += 1;
        setLogs(head.slice(0, i));
        return;
      }
      if (searchTimer.current) window.clearInterval(searchTimer.current);
      setLogs([...head, tail]);
      setResults(output.results);
      setSelectedIds(s.resultMode === "thumbs" ? output.results.map((r) => r.resultId) : []);
      setRunMeta({
        mode: output.mode,
        polarity: s.polarity,
        excludedLocal: output.excludedLocal,
        skippedModel: output.skippedModel,
        skippedPose: output.skippedPose,
        pool: output.pool,
        resultMode: s.resultMode,
        carouselMode: s.carouselMode,
      });
      const label = patch?.forceRandom || output.mode === "random"
        ? "Random draw"
        : s.text.trim() || (s.useImage ? "Reference" : s.usePose ? "Pose" : "Tags");
      setLastSummary(`${s.selectedAccounts.map((h) => "@" + h).join("  ")} · ${label}`);
      setSearching(false);
      if (s.resultMode === "full" && output.results.length) {
        setSavedFull(output.results.map((r) => r.resultId));
        toast(`Saved ${output.results.length} full-size files to picks/`);
      }
    }, delay);
  }, [toast]);

  const cancelFind = () => {
    if (searchTimer.current) window.clearInterval(searchTimer.current);
    setSearching(false);
    setLogs((prev) => [...prev, "cancelled"]);
  };

  const toggleAccount = (handle: string) => {
    setSelectedAccounts((prev) => (prev.includes(handle) ? prev.filter((h) => h !== handle) : [...prev, handle]));
  };

  const addAccount = (raw: string) => {
    const handle = raw.replace(/^@/, "").trim().toLowerCase();
    if (!handle) return;
    setAccounts((prev) => (prev.some((a) => a.handle === handle) ? prev : [...prev, stubAccount(handle)]));
    setSelectedAccounts((prev) => (prev.includes(handle) ? prev : [...prev, handle]));
    toast(`@${handle} added · prepare it before the first long search`);
  };

  const toggleTag = (group: TagGroup, tag: string) => {
    setTags((prev) => {
      const has = prev.some((t) => t.group === group && t.tag === tag);
      return has ? prev.filter((t) => !(t.group === group && t.tag === tag)) : [...prev, { group, tag }];
    });
  };

  const toggleSelected = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const isFav = (id: string) => favs.some((f) => f.id === id || f.id === id.split(":")[0]);

  const toggleFav = (item: { id: string; account: string; src: string; code: string | null; caption: string }, silent = false) => {
    const exists = favs.some((f) => f.id === item.id);
    setFavs((prev) =>
      exists
        ? prev.filter((f) => f.id !== item.id)
        : [{
            id: item.id,
            account: item.account,
            src: item.src,
            code: item.code,
            savedAt: new Date().toISOString(),
            filename: `${item.code || item.id}.jpg`,
            caption: item.caption,
          }, ...prev],
    );
    if (!silent) toast(exists ? "Removed from favourites" : `Copied to favourites/${item.account}/`);
  };

  const saveSelected = (kind: "thumbs" | "full") => {
    if (!selectedIds.length) {
      toast("Nothing selected.");
      return;
    }
    const stamp = new Date().toISOString().slice(0, 16).replace("T", "_").replace(/:/g, "");
    toast(
      kind === "thumbs"
        ? `Saved ${selectedIds.length} thumbnail${selectedIds.length > 1 ? "s" : ""} to picks/${stamp}/`
        : `Fetched ${selectedIds.length} full-size file${selectedIds.length > 1 ? "s" : ""} to picks/${stamp}/`,
    );
    if (kind === "full") setSavedFull((prev) => [...new Set([...prev, ...selectedIds])]);
  };

  const openSlides = (items: Scored[], index: number) => setSlides({ open: true, items, index });
  const closeSlides = () => setSlides((s) => ({ ...s, open: false }));
  const stepSlides = (dir: number) => {
    setSlides((s) => {
      if (!s.items.length) return s;
      const index = (s.index + dir + s.items.length) % s.items.length;
      return { ...s, index };
    });
  };

  const startJob = (partial: Omit<Job, "id" | "status" | "progress" | "log" | "started" | "logPath" | "pid">) => {
    const id = uid("job");
    const job: Job = {
      ...partial,
      id,
      status: "running",
      progress: 8,
      started: Date.now(),
      step: partial.step ?? 12,
      logPath: `cache/jobs/${id}.log`,
      pid: 42000 + Math.floor(Math.random() * 9000),
      log: [],
    };
    job.log = scriptFor(job).slice(0, 1);
    setJobs((prev) => [job, ...prev]);
    setActiveJob(id);
    setJobsOpen(true);
    toast(`${job.title} started`);
  };

  const instagramNeedsSession = (handle: string) => {
    const account = accounts.find((a) => a.handle === handle);
    return !account || account.kind === "instagram";
  };

  const startPrepare = (raw: string, carouselCount: number) => {
    const handle = raw.replace(/^@/, "").trim().toLowerCase();
    if (!handle) {
      toast("Enter an account name.");
      return;
    }
    if (!sessionOk && instagramNeedsSession(handle)) {
      toast("Prepare needs a saved Instagram session.");
      setSessionOpen(true);
      return;
    }
    setAccounts((prev) => (prev.some((a) => a.handle === handle) ? prev : [...prev, stubAccount(handle)]));
    setSelectedAccounts((prev) => (prev.includes(handle) ? prev : [...prev, handle]));
    startJob({ kind: "prepare", account: handle, title: `Prepare @${handle}`, carouselCount, model, step: 11 });
    setPrepareFor(null);
  };

  const startIndex = (handle: string, workers: number, untilDone: boolean, batch: number) => {
    if (!sessionOk && instagramNeedsSession(handle)) {
      toast("Indexing slides loads Instagram. Login first.");
      setSessionOpen(true);
      return;
    }
    startJob({
      kind: "index",
      account: handle,
      title: untilDone ? `Index all slides · @${handle}` : `Index slides · @${handle}`,
      workers,
      untilDone,
      batch,
      step: workers === 1 ? 7 : workers === 2 ? 11 : 15,
    });
  };

  const startPose = (handle: string) => {
    if (!sessionOk && instagramNeedsSession(handle)) {
      toast("Building a pose index needs the saved session.");
      setSessionOpen(true);
      return;
    }
    startJob({ kind: "pose", account: handle, title: `Pose index · @${handle}`, step: 16 });
  };

  const startDetect = (handle: string) => {
    if (!sessionOk && instagramNeedsSession(handle)) {
      toast("Detecting carousels needs the saved session.");
      setSessionOpen(true);
      return;
    }
    startJob({ kind: "detect", account: handle, title: `Detect carousels · @${handle}`, step: 18 });
  };

  const startLibrary = (handle: string) => {
    startJob({ kind: "library", account: handle, title: `Library folders · @${handle}`, step: 18 });
  };

  const stopJob = (id: string) => {
    setJobs((prev) => prev.map((j) => (j.id === id && j.status === "running" ? { ...j, status: "stopped", log: [...j.log, "stopped by user"] } : j)));
  };

  const dismissJob = (id: string) => setJobs((prev) => prev.filter((j) => j.id !== id));

  const startImport = (sourceId: string) => {
    const source = sources.find((s) => s.id === sourceId);
    if (!source) return;
    if (source.pending <= 0) {
      toast("No pending files in that folder.");
      return;
    }
    startJob({
      kind: "import",
      title: `Import ${source.name}`,
      sourceId: source.id,
      sourceKind: source.kind,
      sourceName: source.name,
      pendingCount: source.pending,
      path: source.path,
      account: source.feeds || source.name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
      createCollection: !source.feeds,
      step: 14,
    });
  };

  const startImportAll = () => {
    const pending = sources.filter((s) => s.pending > 0);
    if (!pending.length) {
      toast("No pending files.");
      return;
    }
    pending.forEach((s) => startImport(s.id));
  };

  const addSource = (input: { name: string; path: string; kind: "images" | "videos"; pending: number }) => {
    const id = uid("src");
    const handle = input.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "collection";
    const source: Source = {
      id,
      name: input.name,
      path: input.path,
      kind: input.kind,
      indexed: 0,
      pending: input.pending,
      added: new Date().toISOString().slice(0, 10),
    };
    setSources((prev) => [source, ...prev]);
    startJob({
      kind: "import",
      title: `Import ${input.name}`,
      sourceId: id,
      sourceKind: input.kind,
      sourceName: input.name,
      pendingCount: input.pending,
      path: input.path,
      account: handle,
      createCollection: true,
      step: 12,
    });
    setImportKind(null);
  };

  const reveal = (path: string) => toast(`Finder · ${path}`);

  const pickTag = (group: TagGroup, tag: string) => {
    setGalleryLimit(8);
    const exists = picked.some((t) => t.group === group && t.tag === tag);
    if (exists) {
      setPicked(picked.filter((t) => !(t.group === group && t.tag === tag)));
      return;
    }
    if (picked.some((t) => t.group !== group)) {
      setPendingTag({ group, tag });
      return;
    }
    setPicked([...picked, { group, tag }]);
  };

  const resolvePending = (mode: "alone" | "both") => {
    if (!pendingTag) return;
    setPicked(mode === "alone" ? [pendingTag] : [...picked, pendingTag]);
    setPendingTag(null);
    setGalleryLimit(8);
  };

  const setPile = (id: string, pile: Pile) => {
    setUndoStack((s) => [...s, { id, prev: overrides[id] ?? null }]);
    setOverrides((prev) => ({ ...prev, [id]: pile }));
  };

  const undoPile = () => {
    const last = undoStack[undoStack.length - 1];
    if (!last) return;
    setOverrides((prev) => {
      const next = { ...prev };
      if (last.prev == null) delete next[last.id];
      else next[last.id] = last.prev;
      return next;
    });
    setUndoStack(undoStack.slice(0, -1));
    toast("Undid correction");
  };

  const setKeepAt = (n: number) => setKeepAtState(Math.max(junkAt + 0.05, Math.min(0.95, n)));
  const setJunkAt = (n: number) => setJunkAtState(Math.max(0.05, Math.min(keepAt - 0.05, n)));

  const pileOf = (score: number, id: string): Pile => {
    if (overrides[id]) return overrides[id];
    if (score >= keepAt) return "keep";
    if (score <= junkAt) return "junk";
    return "review";
  };

  const checkSession = () => {
    setChecking(true);
    window.setTimeout(() => {
      setChecking(false);
      const stamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      setSessionChecked(stamp);
      toast(sessionOk ? `Session ok · @mira.chen · ${stamp}` : "Session expired. Login to refresh auth.json.");
    }, 800);
  };

  const resetDesk = () => {
    localStorage.removeItem(KEY);
    window.location.reload();
  };

  const copyText = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
    } catch {
      /* clipboard may be blocked in the preview; the toast still confirms */
    }
    toast(`Copied ${value}`);
  };

  const value = {
    view, setView, model, setModel, sessionOk, setSessionOk, sessionChecked, checking, checkSession,
    accounts, frames, selectedAccounts, toggleAccount, addAccount, sources, autoImport, setAutoImport,
    favs, isFav, toggleFav, jobs, jobsOpen, setJobsOpen, activeJob, setActiveJob, stopJob, dismissJob,
    text, setText, useText, setUseText, useImage, setUseImage, usePose, setUsePose,
    refImage, setRefImage, poseImage, setPoseImage, imageWeight, setImageWeight, mirrorPose, setMirrorPose,
    tags, toggleTag, setTags, confidence, setConfidence, polarity, setPolarity, count, setCount,
    takeAll, setTakeAll, cap, setCap, mix, setMix, dateFrom, setDateFrom, dateTo, setDateTo,
    carouselMode, setCarouselMode, includeVideo, setIncludeVideo, clipLength, setClipLength,
    cacheMode, setCacheMode, resultMode, setResultMode, searching, logs, showLog, setShowLog,
    results, selectedIds, toggleSelected, setSelectedIds, savedFull, runMeta, lastSummary,
    composerOpen, setComposerOpen, find, cancelFind, saveSelected, slides, openSlides, closeSlides, stepSlides,
    libraryAccount, setLibraryAccount, picked, pickTag, pendingTag, setPendingTag, resolvePending,
    clearPicked: () => { setPicked([]); setPendingTag(null); }, galleryLimit, setGalleryLimit,
    collectionsTab, setCollectionsTab, favFilter, setFavFilter, startPrepare, startIndex, startPose,
    startDetect, startLibrary, startImport, startImportAll, addSource, reveal, keepAt, junkAt, setKeepAt,
    setJunkAt, overrides, setPile, undoPile, undoStack, pileOf, toasts, refineOpen, setRefineOpen,
    sessionOpen, setSessionOpen, paletteOpen, setPaletteOpen, prepareFor, setPrepareFor, importKind,
    setImportKind, resetDesk, copyText, toast,
  };

  return <DeskContext.Provider value={value}>{children}</DeskContext.Provider>;
}
